import React, { useEffect, useState } from "react";
import { useSearch } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Search, X } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { EssayCard } from "@/components/content/EssayCard";
import { GridSkeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { contentApi } from "@/lib/api";
import { useDebounce } from "@/hooks/useDebounce";
import { cn } from "@/lib/utils";

const TABS = ["All", "Essays", "Papers", "Archive", "Authors"] as const;
type Tab = typeof TABS[number];

export function SearchPage() {
  const searchStr = useSearch();
  const params = new URLSearchParams(searchStr);
  const initialQ = params.get("q") ?? "";

  const [q, setQ] = useState(initialQ);
  const [tab, setTab] = useState<Tab>("All");
  const debouncedQ = useDebounce(q, 400);

  // Update URL without navigate so it stays shareable
  useEffect(() => {
    const url = new URL(window.location.href);
    if (debouncedQ) url.searchParams.set("q", debouncedQ);
    else url.searchParams.delete("q");
    window.history.replaceState({}, "", url.toString());
  }, [debouncedQ]);

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ["search", debouncedQ, tab],
    queryFn: () => contentApi.search(debouncedQ, tab !== "All" ? { type: tab.toLowerCase() } : undefined),
    enabled: debouncedQ.trim().length > 0,
    staleTime: 60 * 1000,
  });

  const results = data?.results ?? [];
  const total   = data?.total ?? 0;

  return (
    <AppShell>
      <div className="container py-10 max-w-4xl">
        <h1 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-ink)] mb-6">
          Search
        </h1>

        {/* Search input */}
        <div className="relative mb-6">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--color-muted)]" aria-hidden="true" />
          <input
            autoFocus
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search essays, papers, authors, topics…"
            className="w-full pl-11 pr-10 py-3.5 text-base rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-gold)] text-[var(--color-ink)] placeholder:text-[var(--color-muted)]"
          />
          {q && (
            <button onClick={() => setQ("")} className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors" aria-label="Clear search">
              <X size={16} />
            </button>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-[var(--color-border)] mb-8 overflow-x-auto">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                "px-4 py-2.5 text-sm whitespace-nowrap border-b-2 transition-colors",
                tab === t
                  ? "border-[var(--color-gold)] text-[var(--color-ink)] font-medium"
                  : "border-transparent text-[var(--color-muted)] hover:text-[var(--color-ink)]"
              )}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Results */}
        {!debouncedQ.trim() ? (
          <EmptyState
            glyph="🔍"
            title="Start searching"
            description="Search published essays, papers, domains, and authors across the archive."
            compact
          />
        ) : isLoading || isFetching ? (
          <GridSkeleton count={3} />
        ) : results.length > 0 ? (
          <div>
            <p className="text-sm text-[var(--color-muted)] mb-5">
              {total} result{total !== 1 ? "s" : ""} for &ldquo;{debouncedQ}&rdquo;
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {results.map((item) => (
                "publishedAt" in item
                  ? <EssayCard key={item.id} article={item as any} />
                  : null
              ))}
            </div>
          </div>
        ) : (
          <EmptyState
            glyph="🗺"
            title="No results found"
            description={`Nothing matched "${debouncedQ}". Try different keywords or browse by domain.`}
            action={{ label: "Browse domains", href: "/domains" }}
            secondaryAction={{ label: "Clear search", onClick: () => setQ("") }}
          />
        )}
      </div>
    </AppShell>
  );
}
