import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Send, ExternalLink } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Skeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { StatusBadge } from "@/components/ui/Badge";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { Button } from "@/components/ui/Button";
import { useRequireAuth } from "@/lib/auth-context";
import { submissionApi } from "@/lib/api";
import { formatDate } from "@/lib/utils";

const STATUS_HINTS: Record<string, string> = {
  submitted:          "Your work has been received. Editors will review it shortly.",
  under_review:       "An editor is currently reviewing your work.",
  revision_requested: "The editor has requested changes. Open the draft to review their notes and resubmit.",
  resubmitted:        "Your revised work has been resubmitted for review.",
  accepted:           "Your work has been accepted for publication. It will be live soon.",
  rejected:           "Your submission was not accepted. You may revise and resubmit as a new draft.",
  published:          "Your work is now live in the archive.",
};

export function SubmissionsPage() {
  const { user } = useRequireAuth();
  const { data: submissions, isLoading } = useQuery({
    queryKey: ["submissions"],
    queryFn: submissionApi.list,
    enabled: !!user,
  });

  if (!user) return null;

  return (
    <AppShell>
      <div className="container py-10 max-w-3xl">
        <Breadcrumb crumbs={[{ label: "Account", href: "/account" }, { label: "Submissions" }]} className="mb-6" />

        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-ink)]">My Submissions</h1>
            <p className="text-sm text-[var(--color-muted)] mt-1">Track the status of your submitted work.</p>
          </div>
          <Button as="a" href="/write" icon={<Send size={16} />} variant="secondary">Submit work</Button>
        </div>

        {isLoading ? (
          <div className="flex flex-col gap-4">{[1,2].map(i=><Skeleton key={i} className="h-28"/>)}</div>
        ) : !submissions || submissions.length === 0 ? (
          <EmptyState
            glyph="📬"
            title="No submissions yet"
            description="Write or import a manuscript, then submit it for editorial review."
            action={{ label: "Write & submit", href: "/write" }}
            secondaryAction={{ label: "Read submission guidelines", href: "/about#guidelines" }}
          />
        ) : (
          <div className="flex flex-col gap-4">
            {submissions.map((sub) => (
              <div key={sub.id} className="p-5 rounded-[var(--radius-xl)] border border-[var(--color-border)] bg-white">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-[var(--font-display)] font-semibold text-[var(--color-ink)] truncate">{sub.title}</h3>
                    <p className="text-xs text-[var(--color-muted)] mt-0.5">
                      Submitted {formatDate(sub.submittedAt)}
                      {sub.reviewedAt && ` · Reviewed ${formatDate(sub.reviewedAt)}`}
                    </p>
                  </div>
                  <StatusBadge status={sub.status} />
                </div>

                {/* Status explanation */}
                {STATUS_HINTS[sub.status] && (
                  <p className="text-sm text-[var(--color-muted)] mb-3 leading-relaxed">
                    {STATUS_HINTS[sub.status]}
                  </p>
                )}

                {/* Editor note */}
                {sub.adminNote && (
                  <div className="p-3 mb-3 rounded-[var(--radius-md)] bg-[var(--color-rust)]/8 border border-[var(--color-rust)]/20">
                    <p className="text-xs font-semibold text-[var(--color-rust)] mb-1">Editor note</p>
                    <p className="text-sm text-[var(--color-ink)]">{sub.adminNote}</p>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 flex-wrap">
                  {sub.status === "revision_requested" && sub.draftId && (
                    <Button as="a" href={`/write/drafts/${sub.draftId}`} size="sm" variant="primary">
                      Open draft to revise
                    </Button>
                  )}
                  {sub.status === "published" && sub.publishedSlug && (
                    <Button as="a" href={`/essays/${sub.publishedSlug}`} size="sm" variant="secondary" iconRight={<ExternalLink size={13} />}>
                      View published essay
                    </Button>
                  )}
                  {sub.draftId && sub.status !== "revision_requested" && (
                    <Button as="a" href={`/write/drafts/${sub.draftId}`} size="sm" variant="ghost">
                      View draft
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
