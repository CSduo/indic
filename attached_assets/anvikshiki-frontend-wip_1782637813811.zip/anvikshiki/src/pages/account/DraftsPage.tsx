import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, FileText, Trash2, Eye, Edit3 } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/Button";
import { Skeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { StatusBadge } from "@/components/ui/Badge";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { useRequireAuth } from "@/lib/auth-context";
import { draftApi } from "@/lib/api";
import { timeAgo, estimateReadingTime } from "@/lib/utils";
import { toast } from "@/hooks/useToast";

export function DraftsPage() {
  const { user } = useRequireAuth();
  const qc = useQueryClient();
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const { data: drafts, isLoading } = useQuery({
    queryKey: ["drafts"],
    queryFn: draftApi.list,
    enabled: !!user,
  });

  const deleteMutation = useMutation({
    mutationFn: draftApi.delete,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["drafts"] });
      toast("Draft deleted.", "info");
      setDeletingId(null);
    },
    onError: () => { toast("Could not delete draft.", "error"); setDeletingId(null); },
  });

  async function createNewDraft() {
    try {
      const draft = await draftApi.create({ title: "", status: "draft" });
      window.location.href = `/write/drafts/${draft.id}`;
    } catch {
      toast("Could not create draft.", "error");
    }
  }

  if (!user) return null;

  return (
    <AppShell>
      <div className="container py-10 max-w-3xl">
        <Breadcrumb crumbs={[{ label: "Account", href: "/account" }, { label: "Drafts" }]} className="mb-6" />

        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-ink)]">My Drafts</h1>
            <p className="text-sm text-[var(--color-muted)] mt-1">Private until submitted for review.</p>
          </div>
          <Button onClick={createNewDraft} icon={<Plus size={16} />}>New draft</Button>
        </div>

        {isLoading ? (
          <div className="flex flex-col gap-3">{[1,2,3].map(i=><Skeleton key={i} className="h-20"/>)}</div>
        ) : !drafts || drafts.length === 0 ? (
          <EmptyState
            glyph="📝"
            title="No drafts yet"
            description="Start writing from scratch or upload a document to create your first draft."
            action={{ label: "Write from scratch", href: "/write/new" }}
            secondaryAction={{ label: "Upload a document", href: "/write/import" }}
          />
        ) : (
          <div className="flex flex-col gap-3">
            {drafts.map((draft) => (
              <div key={draft.id} className="flex items-center gap-4 p-4 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white group hover:border-[var(--color-gold)]/40 transition-all">
                <FileText size={20} className="text-[var(--color-muted)] shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-[var(--color-ink)] truncate">
                    {draft.title || <span className="italic text-[var(--color-muted)]">Untitled draft</span>}
                  </p>
                  <div className="flex items-center gap-3 mt-0.5 text-xs text-[var(--color-muted)]">
                    {draft.wordCount && <span>{draft.wordCount} words</span>}
                    {draft.wordCount && <span>·</span>}
                    {draft.wordCount && <span>{estimateReadingTime(draft.wordCount)}</span>}
                    <span>·</span>
                    <span>Edited {timeAgo(draft.updatedAt)}</span>
                  </div>
                </div>
                <StatusBadge status={draft.status} />
                <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                  <a href={`/write/drafts/${draft.id}`} className="p-1.5 rounded hover:bg-[var(--color-parchment-dark)] text-[var(--color-muted)] hover:text-[var(--color-teal)] transition-colors" title="Edit">
                    <Edit3 size={15} />
                  </a>
                  <a href={`/write/drafts/${draft.id}/preview`} className="p-1.5 rounded hover:bg-[var(--color-parchment-dark)] text-[var(--color-muted)] hover:text-[var(--color-teal)] transition-colors" title="Preview">
                    <Eye size={15} />
                  </a>
                  {deletingId === draft.id ? (
                    <div className="flex items-center gap-1">
                      <button onClick={() => deleteMutation.mutate(draft.id)} className="text-xs px-2 py-1 bg-red-600 text-white rounded hover:bg-red-700 transition-colors">Confirm</button>
                      <button onClick={() => setDeletingId(null)} className="text-xs px-2 py-1 border border-[var(--color-border)] rounded hover:bg-[var(--color-parchment-dark)] transition-colors">Cancel</button>
                    </div>
                  ) : (
                    <button onClick={() => setDeletingId(draft.id)} className="p-1.5 rounded hover:bg-red-50 text-[var(--color-muted)] hover:text-red-600 transition-colors" title="Delete">
                      <Trash2 size={15} />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
