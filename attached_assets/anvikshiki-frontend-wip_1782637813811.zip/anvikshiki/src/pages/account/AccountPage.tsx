import React from "react";
import { useQuery } from "@tanstack/react-query";
import { PenLine, FileText, Bookmark, Send, Bell, Settings, ArrowRight } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Skeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { StatusBadge } from "@/components/ui/Badge";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import { useRequireAuth } from "@/lib/auth-context";
import { draftApi, submissionApi, savedApi, notificationApi } from "@/lib/api";
import { formatDate, timeAgo } from "@/lib/utils";

export function AccountPage() {
  const { user, loading: authLoading } = useRequireAuth();

  const { data: drafts }        = useQuery({ queryKey: ["drafts"],        queryFn: draftApi.list,        enabled: !!user });
  const { data: submissions }   = useQuery({ queryKey: ["submissions"],   queryFn: submissionApi.list,   enabled: !!user });
  const { data: saved }         = useQuery({ queryKey: ["saved"],         queryFn: savedApi.list,        enabled: !!user });
  const { data: notifications } = useQuery({ queryKey: ["notifications"], queryFn: notificationApi.list, enabled: !!user });

  if (authLoading) {
    return (
      <AppShell>
        <div className="container py-10 max-w-5xl">
          <Skeleton className="w-48 h-8 mb-8" />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[1,2,3,4].map(i => <Skeleton key={i} className="h-24" />)}
          </div>
        </div>
      </AppShell>
    );
  }

  if (!user) return null;

  const unreadNotifs = notifications?.filter((n) => !n.readAt).length ?? 0;

  const stats = [
    { label: "Drafts",       value: drafts?.length ?? 0,      icon: <PenLine size={18} />,  href: "/account/drafts" },
    { label: "Submissions",  value: submissions?.length ?? 0,  icon: <Send size={18} />,     href: "/account/submissions" },
    { label: "Saved items",  value: saved?.length ?? 0,        icon: <Bookmark size={18} />, href: "/account/saved" },
    { label: "Notifications",value: unreadNotifs,              icon: <Bell size={18} />,     href: "/account/notifications" },
  ];

  return (
    <AppShell>
      <div className="container py-10 max-w-5xl">
        {/* Profile banner */}
        <div className="flex items-center gap-5 mb-10 p-6 rounded-[var(--radius-xl)] bg-[var(--color-teal)] text-[var(--color-parchment)]">
          <div className="w-14 h-14 rounded-full bg-[var(--color-parchment)]/20 flex items-center justify-center shrink-0">
            {user.avatarUrl
              ? <img src={user.avatarUrl} alt="" className="w-14 h-14 rounded-full object-cover" />
              : <AnimalGlyph glyph={user.avatarGlyph || "lotus"} size={28} />
            }
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="font-[var(--font-display)] text-xl font-bold">Welcome back, {user.displayName}</h1>
            <p className="text-sm text-[var(--color-parchment)]/60 mt-0.5">{user.email}</p>
          </div>
          <a href="/account/profile" className="shrink-0 flex items-center gap-1.5 text-sm text-[var(--color-parchment)]/70 hover:text-[var(--color-parchment)] transition-colors">
            <Settings size={15} /> Edit profile
          </a>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {stats.map((s) => (
            <a key={s.label} href={s.href} className="group card p-5 flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[var(--color-muted)] group-hover:text-[var(--color-teal)] transition-colors">{s.icon}</span>
                <ArrowRight size={14} className="text-[var(--color-border)] group-hover:text-[var(--color-gold)] transition-colors" />
              </div>
              <div>
                <p className="text-2xl font-bold text-[var(--color-ink)]">{s.value}</p>
                <p className="text-xs text-[var(--color-muted)]">{s.label}</p>
              </div>
            </a>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent drafts */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-[var(--font-display)] text-lg font-semibold text-[var(--color-ink)]">Recent Drafts</h2>
              <a href="/account/drafts" className="text-xs text-[var(--color-muted)] hover:text-[var(--color-ink)] flex items-center gap-1">View all <ArrowRight size={12} /></a>
            </div>
            {!drafts ? (
              <div className="flex flex-col gap-3">{[1,2].map(i=><Skeleton key={i} className="h-16"/>)}</div>
            ) : drafts.length === 0 ? (
              <EmptyState glyph="📝" title="No drafts yet" description="Start writing from the + button." action={{ label: "New draft", href: "/write/new" }} compact />
            ) : (
              <div className="flex flex-col gap-2">
                {drafts.slice(0,4).map((d) => (
                  <a key={d.id} href={`/write/drafts/${d.id}`}
                    className="flex items-center gap-3 p-3.5 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white hover:border-[var(--color-gold)]/50 hover:bg-[var(--color-parchment)] transition-all group"
                  >
                    <FileText size={16} className="text-[var(--color-muted)] shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-[var(--color-ink)] truncate group-hover:text-[var(--color-teal)]">
                        {d.title || "Untitled draft"}
                      </p>
                      <p className="text-xs text-[var(--color-muted)]">
                        {d.wordCount ? `${d.wordCount} words · ` : ""}{timeAgo(d.updatedAt)}
                      </p>
                    </div>
                    <StatusBadge status={d.status} />
                  </a>
                ))}
              </div>
            )}
          </section>

          {/* Submissions */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-[var(--font-display)] text-lg font-semibold text-[var(--color-ink)]">Submissions</h2>
              <a href="/account/submissions" className="text-xs text-[var(--color-muted)] hover:text-[var(--color-ink)] flex items-center gap-1">View all <ArrowRight size={12} /></a>
            </div>
            {!submissions ? (
              <div className="flex flex-col gap-3">{[1,2].map(i=><Skeleton key={i} className="h-16"/>)}</div>
            ) : submissions.length === 0 ? (
              <EmptyState glyph="📬" title="No submissions yet" description="Submit a draft for editorial review." action={{ label: "Submit work", href: "/write" }} compact />
            ) : (
              <div className="flex flex-col gap-2">
                {submissions.slice(0,4).map((s) => (
                  <div key={s.id} className="flex items-center gap-3 p-3.5 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-[var(--color-ink)] truncate">{s.title}</p>
                      <p className="text-xs text-[var(--color-muted)]">Submitted {formatDate(s.submittedAt)}</p>
                      {s.adminNote && (
                        <p className="text-xs text-[var(--color-rust)] mt-0.5 truncate">Editor: {s.adminNote}</p>
                      )}
                    </div>
                    <StatusBadge status={s.status} />
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </AppShell>
  );
}
