import React from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Users } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { HeroPanel } from "@/components/hero/HeroPanel";
import { EssayCard } from "@/components/content/EssayCard";
import { DomainCard } from "@/components/content/DomainCard";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import { GridSkeleton, Skeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { useAuth } from "@/lib/auth-context";
import { contentApi } from "@/lib/api";
import { DOMAINS, SITE_DESCRIPTION } from "@/lib/constants";

export function HomePage() {
  const { user } = useAuth();

  const { data: home, isLoading } = useQuery({
    queryKey: ["home"],
    queryFn: contentApi.home,
    staleTime: 5 * 60 * 1000,
  });

  const heroActions = user
    ? [
        { label: "Explore Archive", href: "/archive", variant: "primary" as const },
        { label: "Write & Submit", href: "/write", variant: "ghost" as const },
      ]
    : [
        { label: "Explore Archive", href: "/archive", variant: "primary" as const },
        { label: "Submit Your Work", href: "/signup", variant: "ghost" as const },
      ];

  return (
    <AppShell fullBleed>
      {/* Hero */}
      <HeroPanel
        variant="knowledge-journey"
        eyebrow="A journey through"
        headline={"Ideas. Archives.\nCivilizational Wisdom."}
        subline={SITE_DESCRIPTION}
        actions={heroActions}
        minHeight="min-h-[72vh]"
      />

      {/* Browse by Domain */}
      <section className="py-14">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div>
              <p className="eyebrow mb-1.5">Browse by Domain</p>
              <h2 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-ink)]">
                Fields of Inquiry
              </h2>
            </div>
            <a
              href="/domains"
              className="hidden sm:flex items-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors"
            >
              View all domains
              <ArrowRight size={14} />
            </a>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {DOMAINS.slice(0, 6).map((domain) => (
              <DomainCard
                key={domain.slug}
                domain={domain}
                compact
                contentCount={
                  home?.domains?.find((d) => d.slug === domain.slug)?.contentCount
                }
              />
            ))}
          </div>
        </div>
      </section>

      {/* Featured essay + Latest papers */}
      <section className="py-8 border-t border-[var(--color-border)]">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Featured essay */}
            <div className="lg:col-span-2">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <p className="eyebrow mb-1">Featured Essay</p>
                </div>
              </div>

              {isLoading ? (
                <Skeleton className="w-full h-72" />
              ) : home?.featured ? (
                <EssayCard article={home.featured} featured layout="grid" />
              ) : (
                <EmptyState
                  glyph="📜"
                  title="No essays published yet"
                  description="The archive awaits the first voice. Submit your inquiry to begin."
                  action={{ label: "Submit work", href: "/write" }}
                  compact
                />
              )}
            </div>

            {/* Latest papers */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <p className="eyebrow">Latest Papers</p>
                <a
                  href="/papers"
                  className="text-xs text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors flex items-center gap-1"
                >
                  View all <ArrowRight size={12} />
                </a>
              </div>

              {isLoading ? (
                <div className="flex flex-col gap-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex flex-col gap-2 p-3 border border-[var(--color-border)] rounded-[var(--radius-lg)]">
                      <Skeleton className="w-16 h-3" />
                      <Skeleton className="w-full h-4" />
                      <Skeleton className="w-4/5 h-4" />
                      <Skeleton className="w-24 h-3 mt-1" />
                    </div>
                  ))}
                </div>
              ) : home?.latestPapers && home.latestPapers.length > 0 ? (
                <div className="flex flex-col gap-3">
                  {home.latestPapers.slice(0, 3).map((paper) => (
                    <a
                      key={paper.id}
                      href={`/papers/${paper.slug}`}
                      className="group flex flex-col gap-1.5 p-3.5 border border-[var(--color-border)] rounded-[var(--radius-lg)] bg-white hover:border-[var(--color-gold)]/50 hover:bg-[var(--color-parchment)] transition-all duration-150"
                    >
                      <p className="eyebrow">{paper.domain}</p>
                      <p className="text-sm font-[var(--font-display)] font-semibold text-[var(--color-ink)] group-hover:text-[var(--color-teal)] transition-colors line-clamp-2 leading-snug">
                        {paper.title}
                      </p>
                      <p className="text-xs text-[var(--color-muted)]">
                        {paper.authors[0]}
                      </p>
                    </a>
                  ))}
                </div>
              ) : (
                <EmptyState
                  glyph="🗂"
                  title="No papers yet"
                  description="Research papers will appear here once published."
                  compact
                />
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Latest essays */}
      <section className="py-12 border-t border-[var(--color-border)]">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div>
              <p className="eyebrow mb-1.5">Recent from the Archive</p>
              <h2 className="font-[var(--font-display)] text-xl font-bold text-[var(--color-ink)]">
                Latest Essays
              </h2>
            </div>
            <a
              href="/essays"
              className="flex items-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors"
            >
              View all <ArrowRight size={14} />
            </a>
          </div>

          {isLoading ? (
            <GridSkeleton count={3} />
          ) : home?.latestEssays && home.latestEssays.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {home.latestEssays.slice(0, 3).map((article) => (
                <EssayCard key={article.id} article={article} />
              ))}
            </div>
          ) : (
            <EmptyState
              glyph="📖"
              title="Archive awaiting essays"
              description="Be among the first to contribute. Submit your work for editorial review."
              action={{ label: "Submit an essay", href: "/write" }}
              secondaryAction={{ label: "Browse domains", href: "/domains" }}
            />
          )}
        </div>
      </section>

      {/* Community CTA */}
      <section className="py-14 section-dark">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-6">
            <div
              className="flex gap-2 shrink-0"
              aria-hidden="true"
            >
              {["elephant", "owl", "tiger", "serpent"].map((g) => (
                <AnimalGlyph
                  key={g}
                  glyph={g}
                  size={24}
                  color="var(--color-gold)"
                  className="opacity-70"
                />
              ))}
            </div>
            <div>
              <p className="eyebrow text-[var(--color-gold)] mb-1">A community of curious minds</p>
              <h2 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-parchment)]">
                Engage in meaningful discussion.
              </h2>
              <p className="text-sm text-[var(--color-parchment)]/60 mt-1.5 max-w-md">
                Share ideas, challenge perspectives, and preserve wisdom alongside scholars and thinkers.
              </p>
            </div>
          </div>
          <a
            href={user ? "/community/feed" : "/signup"}
            className="shrink-0 inline-flex items-center gap-2 px-6 py-3 bg-[var(--color-gold)] hover:bg-[var(--color-gold-light)] text-[var(--color-ink)] font-medium text-sm rounded-full transition-colors"
          >
            <Users size={16} aria-hidden="true" />
            {user ? "Community feed" : "Join community"}
          </a>
        </div>
      </section>
    </AppShell>
  );
}
