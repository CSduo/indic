import React, { useEffect, useRef, useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Bookmark, Share2, Link2, ChevronDown, ChevronUp } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { Skeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { Badge } from "@/components/ui/Badge";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import { contentApi, savedApi } from "@/lib/api";
import { DOMAINS } from "@/lib/constants";
import { formatDateLong, estimateReadingTime } from "@/lib/utils";
import { useAuth } from "@/lib/auth-context";
import { toast } from "@/hooks/useToast";
import { cn } from "@/lib/utils";

type FontSize = "sm" | "md" | "lg";
type Theme    = "light" | "sepia" | "dark";

export function EssayDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const { user } = useAuth();
  const [fontSize, setFontSize]   = useState<FontSize>("md");
  const [theme, setTheme]         = useState<Theme>("light");
  const [tocOpen, setTocOpen]     = useState(false);
  const [saved, setSaved]         = useState(false);
  const [progress, setProgress]   = useState(0);
  const articleRef = useRef<HTMLElement>(null);

  const { data: article, isLoading, isError } = useQuery({
    queryKey: ["essay", slug],
    queryFn: () => contentApi.essay(slug!),
    enabled: !!slug,
  });

  // Reading progress bar
  useEffect(() => {
    const onScroll = () => {
      const el = articleRef.current;
      if (!el) return;
      const { top, height } = el.getBoundingClientRect();
      const scrolled = Math.min(100, Math.max(0, (-top / (height - window.innerHeight)) * 100));
      setProgress(scrolled);
      document.documentElement.style.setProperty("--progress", `${scrolled}%`);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const domain = article ? DOMAINS.find((d) => d.slug === article.domain) : null;

  async function handleSave() {
    if (!user) { toast("Sign in to save essays.", "info"); return; }
    if (!article) return;
    try {
      if (saved) {
        setSaved(false);
        toast("Removed from saved.", "info");
      } else {
        await savedApi.save("essay", article.id);
        setSaved(true);
        toast("Essay saved to your library.", "success");
      }
    } catch {
      toast("Could not save. Try again.", "error");
    }
  }

  function handleShare() {
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({ title: article?.title, url }).catch(() => {});
    } else {
      navigator.clipboard.writeText(url).then(() => toast("Link copied.", "success"));
    }
  }

  const fontSizeClasses: Record<FontSize, string> = {
    sm: "text-base",
    md: "text-lg",
    lg: "text-xl",
  };
  const themeClasses: Record<Theme, string> = {
    light: "bg-white text-[var(--color-ink)]",
    sepia: "bg-[#FAF4E8] text-[#3D2B1F]",
    dark:  "bg-[#1A1A1A] text-[#E8E0D0]",
  };

  if (isLoading) {
    return (
      <AppShell>
        <div className="container py-10 max-w-3xl">
          <Skeleton className="w-32 h-4 mb-8" />
          <Skeleton className="w-full h-10 mb-3" />
          <Skeleton className="w-4/5 h-10 mb-6" />
          <Skeleton className="w-64 h-4 mb-10" />
          <Skeleton className="w-full h-72 mb-8" />
          {[1,2,3,4].map(i => <Skeleton key={i} className="w-full h-5 mb-3" />)}
        </div>
      </AppShell>
    );
  }

  if (isError || !article) {
    return (
      <AppShell>
        <div className="container py-20">
          <EmptyState
            glyph="🗺"
            title="Essay not found"
            description="This essay may have moved or been unpublished."
            action={{ label: "Browse essays", href: "/essays" }}
            secondaryAction={{ label: "Search", href: "/search" }}
          />
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      {/* Reading progress bar */}
      <div className="reading-progress" aria-hidden="true" />

      <div className="container py-8 max-w-4xl">
        {/* Breadcrumb */}
        <Breadcrumb
          backHref="/essays"
          backLabel="Essays"
          crumbs={[
            { label: "Essays", href: "/essays" },
            { label: domain?.name ?? article.domain, href: `/domains/${article.domain}` },
            { label: article.title },
          ]}
          className="mb-8"
        />

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_220px] gap-10 items-start">
          {/* Main content */}
          <article ref={articleRef}>
            {/* Hero image */}
            {article.coverImage && (
              <div className="mb-8 rounded-[var(--radius-xl)] overflow-hidden">
                <img src={article.coverImage} alt={article.title} className="w-full h-auto max-h-[480px] object-cover" />
              </div>
            )}

            {/* Domain badge */}
            <div className="flex items-center gap-2 mb-4">
              {domain && <AnimalGlyph glyph={domain.glyph} size={16} className="text-[var(--color-rust)]" />}
              <span className="eyebrow">{domain?.name ?? article.domain}</span>
            </div>

            {/* Title */}
            <h1 className="font-[var(--font-display)] text-3xl md:text-4xl font-bold text-[var(--color-ink)] leading-tight mb-3">
              {article.title}
            </h1>
            {article.subtitle && (
              <p className="text-xl text-[var(--color-muted)] font-[var(--font-display)] mb-6 leading-snug">
                {article.subtitle}
              </p>
            )}

            {/* Author + meta */}
            <div className="flex items-center justify-between gap-4 pb-6 border-b border-[var(--color-border)] mb-6">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-[var(--color-teal)] flex items-center justify-center text-[var(--color-parchment)] text-sm font-bold shrink-0">
                  {article.authorName[0]}
                </div>
                <div>
                  <p className="text-sm font-medium text-[var(--color-ink)]">{article.authorName}</p>
                  <p className="text-xs text-[var(--color-muted)]">
                    {formatDateLong(article.publishedAt)}
                    {article.readingTime && ` · ${article.readingTime} min read`}
                    {article.wordCount && !article.readingTime && ` · ${estimateReadingTime(article.wordCount)}`}
                  </p>
                </div>
              </div>
              {/* Actions */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleSave}
                  title="Save"
                  className={cn("p-2 rounded-full hover:bg-[var(--color-parchment-dark)] transition-colors", saved ? "text-[var(--color-gold)]" : "text-[var(--color-muted)]")}
                  aria-label="Save essay"
                >
                  <Bookmark size={18} fill={saved ? "currentColor" : "none"} />
                </button>
                <button
                  onClick={handleShare}
                  title="Share"
                  className="p-2 rounded-full hover:bg-[var(--color-parchment-dark)] text-[var(--color-muted)] transition-colors"
                  aria-label="Share essay"
                >
                  <Share2 size={18} />
                </button>
              </div>
            </div>

            {/* Reading controls */}
            <div className="flex flex-wrap items-center gap-3 mb-8 p-3 bg-[var(--color-parchment-dark)] rounded-[var(--radius-lg)] text-xs">
              <span className="text-[var(--color-muted)] font-medium">Reading controls</span>
              <div className="flex items-center gap-1 ml-auto">
                {(["sm","md","lg"] as FontSize[]).map((s) => (
                  <button key={s} onClick={() => setFontSize(s)}
                    className={cn("px-2.5 py-1 rounded font-medium transition-colors", fontSize === s ? "bg-white text-[var(--color-ink)] shadow-sm" : "text-[var(--color-muted)] hover:text-[var(--color-ink)]")}
                  >
                    {s === "sm" ? "A" : s === "md" ? "A" : "A"}
                  </button>
                ))}
              </div>
              {(["light","sepia","dark"] as Theme[]).map((t) => (
                <button key={t} onClick={() => setTheme(t)}
                  className={cn("px-2.5 py-1 rounded capitalize transition-colors", theme === t ? "bg-white text-[var(--color-ink)] shadow-sm" : "text-[var(--color-muted)] hover:text-[var(--color-ink)]")}
                >
                  {t}
                </button>
              ))}
            </div>

            {/* Mobile TOC */}
            {article.contentHtml && (
              <div className="lg:hidden mb-6 border border-[var(--color-border)] rounded-[var(--radius-lg)] overflow-hidden">
                <button
                  onClick={() => setTocOpen((p) => !p)}
                  className="w-full flex items-center justify-between px-4 py-3 bg-[var(--color-parchment-dark)] text-sm font-medium text-[var(--color-ink)]"
                >
                  In this essay
                  {tocOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </button>
              </div>
            )}

            {/* Article body */}
            <div
              className={cn(
                "prose max-w-none rounded-[var(--radius-lg)] p-0.5 transition-colors",
                fontSizeClasses[fontSize],
                themeClasses[theme]
              )}
              dangerouslySetInnerHTML={{ __html: article.contentHtml ?? "<p>Content not available.</p>" }}
            />

            {/* Author bio */}
            {article.authorBio && (
              <div className="mt-10 pt-8 border-t border-[var(--color-border)]">
                <p className="eyebrow mb-3">About the author</p>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-[var(--color-teal)] flex items-center justify-center text-[var(--color-parchment)] text-sm font-bold shrink-0">
                    {article.authorName[0]}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-[var(--color-ink)]">{article.authorName}</p>
                    <p className="text-sm text-[var(--color-muted)] mt-1 leading-relaxed">{article.authorBio}</p>
                  </div>
                </div>
              </div>
            )}
          </article>

          {/* Sidebar TOC — desktop */}
          <aside className="hidden lg:block sticky top-[calc(var(--header-height)+2rem)]">
            <p className="eyebrow mb-4">In this essay</p>
            <div className="text-sm text-[var(--color-muted)] space-y-2">
              <p className="italic">Table of contents appears here when headings are present in the content.</p>
            </div>

            {/* Tags */}
            {article.tags && article.tags.length > 0 && (
              <div className="mt-6">
                <p className="eyebrow mb-3">Tags</p>
                <div className="flex flex-wrap gap-1.5">
                  {article.tags.map((tag) => (
                    <a key={tag} href={`/search?q=${encodeURIComponent(tag)}`}
                      className="text-xs px-2.5 py-1 rounded-full border border-[var(--color-border)] bg-white text-[var(--color-muted)] hover:border-[var(--color-gold)]/50 hover:text-[var(--color-ink)] transition-colors"
                    >
                      {tag}
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Share */}
            <div className="mt-6 flex flex-col gap-2">
              <button
                onClick={handleShare}
                className="flex items-center gap-2 text-sm text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors"
              >
                <Link2 size={14} /> Copy link
              </button>
            </div>
          </aside>
        </div>
      </div>
    </AppShell>
  );
}
