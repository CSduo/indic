import React, { useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import { useAuth } from "@/lib/auth-context";
import { SITE_NAME, SITE_DESCRIPTION } from "@/lib/constants";
import { ApiError } from "@/lib/api";
import { cn } from "@/lib/utils";

export function LoginPage() {
  const { login } = useAuth();
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [error, setError]       = useState("");
  const [loading, setLoading]   = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(email, password);
      const redirect = new URLSearchParams(window.location.search).get("redirect") || "/";
      window.location.href = redirect;
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Sign in failed. Please check your credentials.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AppShell hideFooter>
      <div className="min-h-[calc(100vh-var(--header-height))] flex">
        {/* Left panel — decorative */}
        <div className="hidden lg:flex lg:w-2/5 bg-[var(--color-teal)] flex-col justify-end p-12 relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='6' height='6' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h3v3H0zM3 3h3v3H3z' fill='%23F1EBD6'/%3E%3C/svg%3E\")" }} aria-hidden="true" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[var(--color-parchment)]/5 font-[var(--font-display)] leading-none pointer-events-none select-none" style={{ fontSize: "clamp(8rem,18vw,14rem)" }} aria-hidden="true">ज्ञान</div>
          <div className="relative z-10">
            <p className="font-[var(--font-classical)] text-xs tracking-widest text-[var(--color-gold)] uppercase mb-4">{SITE_NAME}</p>
            <p className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-parchment)] leading-snug mb-3">Welcome back to the archive.</p>
            <p className="text-sm text-[var(--color-parchment)]/60 leading-relaxed">{SITE_DESCRIPTION}</p>
          </div>
        </div>

        {/* Right panel — form */}
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="w-full max-w-sm">
            <div className="flex items-center gap-2 mb-8">
              <AnimalGlyph glyph="lotus" size={24} className="text-[var(--color-teal)]" />
              <span className="font-[var(--font-classical)] text-sm tracking-widest text-[var(--color-teal)] uppercase">{SITE_NAME}</span>
            </div>

            <h1 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-ink)] mb-1">Sign in</h1>
            <p className="text-sm text-[var(--color-muted)] mb-8">Continue your inquiry.</p>

            {error && (
              <div className="mb-5 p-3.5 rounded-[var(--radius-md)] bg-red-50 border border-red-200 text-sm text-red-700" role="alert">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
              <Input
                label="Email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                autoComplete="email"
                required
              />
              <Input
                label="Password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                required
              />
              <Button type="submit" loading={loading} fullWidth size="lg" className="mt-2">
                Sign in
              </Button>
            </form>

            <p className="text-center text-sm text-[var(--color-muted)] mt-6">
              No account yet?{" "}
              <a href="/signup" className="text-[var(--color-teal)] hover:underline underline-offset-2 font-medium">
                Join Ānvīkṣikī
              </a>
            </p>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
