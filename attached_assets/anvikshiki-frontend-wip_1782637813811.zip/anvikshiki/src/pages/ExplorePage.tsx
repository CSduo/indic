import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Map, Clock, BookOpen, Layers } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { DomainCard } from "@/components/content/DomainCard";
import { HeroPanel } from "@/components/hero/HeroPanel";
import { EmptyState } from "@/components/ui/EmptyState";
import { GridSkeleton } from "@/components/ui/Skeleton";
import { contentApi } from "@/lib/api";
import { DOMAINS } from "@/lib/constants";

const QUICK_NAV = [
  { icon: <BookOpen size={20} />, label: "Explore Hub",        desc: "Discover domains, themes & more",   href: "/domains" },
  { icon: <Map size={20} />,      label: "Maps & Timelines",    desc: "Trace ideas across time & space",   href: "/archive?view=maps" },
  { icon: <Layers size={20} />,   label: "Visual Collections",  desc: "Art, manuscripts & artifacts",      href: "/archive?view=collections" },
  { icon: <Clock size={20} />,    label: "Timelines",           desc: "Historical events & periods",       href: "/archive?view=timelines" },
];

export function ExplorePage() {
  const { data: domains, isLoading } = useQuery({
    queryKey: ["domains"],
    queryFn: contentApi.domains,
    staleTime: 10 * 60 * 1000,
  });

  return (
    <AppShell fullBleed>
      <HeroPanel
        variant="archive-scribe"
        eyebrow="Discovery"
        headline={"Explore.\nUnderstand.\nRemember."}
        subline="Journeys of knowledge across civilizations and time."
        actions={[
          { label: "Explore Now", href: "/domains", variant: "primary" },
          { label: "Browse Collections", href: "/archive", variant: "ghost" },
        ]}
        minHeight="min-h-[55vh]"
      />

      {/* Quick navigation */}
      <section className="py-12">
        <div className="container">
          <p className="eyebrow mb-6">Quick Navigation</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {QUICK_NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="group flex flex-col gap-3 p-5 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white hover:border-[var(--color-gold)]/50 hover:bg-[var(--color-parchment)] transition-all duration-200"
              >
                <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[var(--color-parchment-dark)] text-[var(--color-teal)] group-hover:bg-[var(--color-gold)]/15 transition-colors">
                  {item.icon}
                </div>
                <div>
                  <p className="text-sm font-semibold text-[var(--color-ink)]">{item.label}</p>
                  <p className="text-xs text-[var(--color-muted)] mt-0.5">{item.desc}</p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Browse by Domain */}
      <section className="py-8 border-t border-[var(--color-border)]">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div>
              <p className="eyebrow mb-1.5">Browse by Domain</p>
              <h2 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-ink)]">
                All Fields of Inquiry
              </h2>
            </div>
          </div>

          {isLoading ? (
            <GridSkeleton count={6} />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {DOMAINS.map((domain) => {
                const apiDomain = domains?.find((d) => d.slug === domain.slug);
                return (
                  <DomainCard
                    key={domain.slug}
                    domain={domain}
                    contentCount={apiDomain?.contentCount ?? 0}
                  />
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Archive teaser */}
      <section className="py-12 section-dark">
        <div className="container text-center">
          <p className="eyebrow text-[var(--color-gold)] mb-3">Maps & Timelines</p>
          <h2 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-parchment)] mb-4">
            Trace ideas across time and space
          </h2>
          <p className="text-[var(--color-parchment)]/60 text-sm max-w-lg mx-auto mb-6">
            Interactive maps and timelines to explore trade routes, civilizations, ideas, and events across recorded history.
          </p>
          <a href="/archive?view=maps" className="inline-flex items-center gap-2 px-5 py-2.5 bg-[var(--color-gold)] text-[var(--color-ink)] font-medium text-sm rounded-full hover:bg-[var(--color-gold-light)] transition-colors">
            <Map size={16} aria-hidden="true" />
            Explore maps
          </a>
        </div>
      </section>
    </AppShell>
  );
}
