import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { LayoutGrid, List } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { EssayCard } from "@/components/content/EssayCard";
import { GridSkeleton } from "@/components/ui/Skeleton";
import { EmptyState } from "@/components/ui/EmptyState";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import { contentApi } from "@/lib/api";
import { DOMAINS } from "@/lib/constants";
import { useDebounce } from "@/hooks/useDebounce";
import { cn } from "@/lib/utils";

export function EssaysPage() {
  const [layout, setLayout] = useState<"grid" | "list">("grid");
  const [domain, setDomain] = useState("");
  const [sort, setSort] = useState("newest");
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounce(search, 300);

  const { data, isLoading } = useQuery({
    queryKey: ["essays", { domain, sort, q: debouncedSearch }],
    queryFn: () => contentApi.essays({ ...(domain ? { domain } : {}), sort, ...(debouncedSearch ? { q: debouncedSearch } : {}) }),
    staleTime: 2 * 60 * 1000,
  });

  const essays = data?.data ?? [];

  return (
    <AppShell>
      <div className="container py-10">
        <div className="mb-8">
          <p className="eyebrow mb-2">Public journal</p>
          <h1 className="font-[var(--font-display)] text-4xl font-bold text-[var(--color-ink)] mb-3">Essays</h1>
          <p className="text-[var(--color-muted)] max-w-xl">Long-form inquiry across philosophy, history, culture, science, and civilizational thought.</p>
        </div>

        {/* Domain chips */}
        <div className="flex items-center gap-2 flex-wrap mb-6">
          <button onClick={() => setDomain("")} className={cn("px-3 py-1.5 rounded-full text-xs font-medium border transition-all", !domain ? "bg-[var(--color-ink)] text-[var(--color-parchment)] border-[var(--color-ink)]" : "bg-white text-[var(--color-muted)] border-[var(--color-border)] hover:border-[var(--color-ink)]")}>All topics</button>
          {DOMAINS.map((d) => (
            <button key={d.slug} onClick={() => setDomain(d.slug === domain ? "" : d.slug)} className={cn("flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all", domain === d.slug ? "bg-[var(--color-teal)] text-[var(--color-parchment)] border-[var(--color-teal)]" : "bg-white text-[var(--color-muted)] border-[var(--color-border)] hover:border-[var(--color-teal)]")}>
              <AnimalGlyph glyph={d.glyph} size={12} />{d.name}
            </button>
          ))}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3 mb-8 flex-wrap">
          <Input placeholder="Search essays…" value={search} onChange={(e) => setSearch(e.target.value)} fullWidth={false} className="w-64" />
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="text-sm border border-[var(--color-border)] rounded-[var(--radius-md)] px-3 py-2.5 bg-white text-[var(--color-ink)] focus:outline-none focus:ring-1 focus:ring-[var(--color-gold)]">
            <option value="newest">Newest first</option>
            <option value="oldest">Oldest first</option>
            <option value="popular">Most popular</option>
          </select>
          <div className="flex items-center border border-[var(--color-border)] rounded-[var(--radius-md)] overflow-hidden ml-auto">
            <button onClick={() => setLayout("grid")} className={cn("px-3 py-2 transition-colors", layout === "grid" ? "bg-[var(--color-ink)] text-white" : "bg-white text-[var(--color-muted)] hover:bg-[var(--color-parchment-dark)]")} aria-label="Grid view"><LayoutGrid size={15} /></button>
            <button onClick={() => setLayout("list")} className={cn("px-3 py-2 transition-colors", layout === "list" ? "bg-[var(--color-ink)] text-white" : "bg-white text-[var(--color-muted)] hover:bg-[var(--color-parchment-dark)]")} aria-label="List view"><List size={15} /></button>
          </div>
        </div>

        {isLoading ? <GridSkeleton count={6} /> : essays.length === 0 ? (
          <EmptyState glyph="📖" title={debouncedSearch ? "No results found" : "No essays yet"} description={debouncedSearch ? `No essays match "${debouncedSearch}".` : "This domain is awaiting publication."} action={debouncedSearch ? { label: "Clear search", onClick: () => setSearch("") } : { label: "Submit an essay", href: "/write" }} />
        ) : layout === "grid" ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">{essays.map((a) => <EssayCard key={a.id} article={a} />)}</div>
        ) : (
          <div className="flex flex-col gap-3">{essays.map((a) => <EssayCard key={a.id} article={a} layout="list" />)}</div>
        )}

        {data?.hasMore && <div className="flex justify-center mt-10"><Button variant="outline">Load more essays</Button></div>}
      </div>
    </AppShell>
  );
}
