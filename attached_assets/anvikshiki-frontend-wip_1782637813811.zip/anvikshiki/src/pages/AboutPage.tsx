// ─── About ─────────────────────────────────────────────────────────────────────
import React from "react";
import { AppShell } from "@/components/layout/AppShell";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import { SITE_NAME, SITE_DESCRIPTION, DOMAINS } from "@/lib/constants";

export function AboutPage() {
  return (
    <AppShell>
      <div className="container py-14 max-w-3xl">
        <p className="eyebrow mb-3">About the platform</p>
        <h1 className="font-[var(--font-display)] text-4xl font-bold text-[var(--color-ink)] mb-6 leading-tight">
          What is Ānvīkṣikī?
        </h1>

        <div className="prose text-base leading-relaxed mb-10">
          <p>
            <strong>Ānvīkṣikī</strong> — from the Sanskrit root meaning "to look at closely" — is an independent journal and research platform dedicated to inquiry across time, traditions, and civilizations.
          </p>
          <p>
            We publish essays, research papers, translations, commentaries, and archive materials in philosophy, history, psychology, sociology, science, geopolitics, culture, music, and living traditions. Our editorial frame is civilizational and cross-disciplinary; our commitment is to serious, original thought expressed with clarity.
          </p>
          <p>
            Ānvīkṣikī operates on the belief that the greatest questions — about justice, meaning, memory, community, and the cosmos — do not belong to any single era or tradition. They return across civilizations, renewed by every generation that has the courage to look at them closely.
          </p>
        </div>

        <div className="ornament-divider">Our domains</div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8 mb-12">
          {DOMAINS.map((d) => (
            <div key={d.slug} className="flex items-start gap-3 p-4 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white">
              <AnimalGlyph glyph={d.glyph} size={20} className="text-[var(--color-teal)] shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-[var(--color-ink)]">{d.name}</p>
                <p className="text-xs text-[var(--color-muted)] mt-0.5">{d.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div id="guidelines" className="pt-8 border-t border-[var(--color-border)]">
          <div className="ornament-divider">Submission guidelines</div>
          <div className="prose text-base mt-6">
            <p>We welcome essays, academic papers, working papers, translations, commentaries, research notes, and visual essays. We do not publish news, opinion pieces without scholarly grounding, or content that is merely reactive.</p>
            <ul>
              <li>All submissions must be original and unpublished work.</li>
              <li>Essays typically range from 1,500 to 8,000 words. Papers may be longer.</li>
              <li>Citations and references are expected for factual claims.</li>
              <li>We accept Sanskrit diacritics, Devanagari text, and multilingual quotations.</li>
              <li>Review time is typically 2–4 weeks. We respond to every submission.</li>
              <li>Accepted works may be lightly edited for house style and clarity.</li>
              <li>Authors retain rights to their work.</li>
            </ul>
            <p>Submit through the writer studio by clicking the + button or visiting <a href="/write">/write</a>.</p>
          </div>
        </div>

        <div id="contact" className="mt-12 pt-8 border-t border-[var(--color-border)]">
          <div className="ornament-divider">Contact</div>
          <p className="text-sm text-[var(--color-muted)] mt-4">
            For editorial enquiries, please use the submission form or reach us at{" "}
            <a href="mailto:contact@anvikshiki.in" className="text-[var(--color-teal)] underline underline-offset-2">contact@anvikshiki.in</a>.
            Social and community contact details are available once configured by the editorial team.
          </p>
        </div>
      </div>
    </AppShell>
  );
}
