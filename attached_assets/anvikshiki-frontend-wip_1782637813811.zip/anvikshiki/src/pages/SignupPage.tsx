import React, { useState } from "react";
import { Check } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import { useAuth } from "@/lib/auth-context";
import { INTEREST_TAGS, AVATAR_GLYPHS, SITE_NAME } from "@/lib/constants";
import { ApiError } from "@/lib/api";
import { cn } from "@/lib/utils";

type Step = 1 | 2 | 3;

export function SignupPage() {
  const { signup } = useAuth();
  const [step, setStep]             = useState<Step>(1);
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail]           = useState("");
  const [password, setPassword]     = useState("");
  const [interests, setInterests]   = useState<string[]>([]);
  const [glyph, setGlyph]           = useState("lotus");
  const [error, setError]           = useState("");
  const [loading, setLoading]       = useState(false);

  function toggleInterest(tag: string) {
    setInterests((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  }

  async function handleSubmit() {
    setError("");
    setLoading(true);
    try {
      await signup({ email, password, displayName, interests, avatarGlyph: glyph });
      const redirect = new URLSearchParams(window.location.search).get("redirect") || "/";
      window.location.href = redirect;
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not create account. Please try again.");
      setStep(1);
    } finally {
      setLoading(false);
    }
  }

  return (
    <AppShell hideFooter>
      <div className="min-h-[calc(100vh-var(--header-height))] flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          {/* Progress */}
          <div className="flex items-center gap-2 mb-8">
            {([1,2,3] as Step[]).map((s) => (
              <React.Fragment key={s}>
                <div className={cn("w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium transition-colors", step >= s ? "bg-[var(--color-teal)] text-[var(--color-parchment)]" : "bg-[var(--color-parchment-dark)] text-[var(--color-muted)]")}>
                  {step > s ? <Check size={12} /> : s}
                </div>
                {s < 3 && <div className={cn("flex-1 h-px transition-colors", step > s ? "bg-[var(--color-teal)]" : "bg-[var(--color-border)]")} />}
              </React.Fragment>
            ))}
          </div>

          {error && (
            <div className="mb-5 p-3.5 rounded-[var(--radius-md)] bg-red-50 border border-red-200 text-sm text-red-700" role="alert">
              {error}
            </div>
          )}

          {/* Step 1: credentials */}
          {step === 1 && (
            <div>
              <div className="flex items-center gap-2 mb-6">
                <AnimalGlyph glyph="lotus" size={24} className="text-[var(--color-teal)]" />
                <span className="font-[var(--font-classical)] text-sm tracking-widest text-[var(--color-teal)] uppercase">{SITE_NAME}</span>
              </div>
              <h1 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-ink)] mb-1">Join the inquiry</h1>
              <p className="text-sm text-[var(--color-muted)] mb-8">Create your Ānvīkṣikī account.</p>
              <form onSubmit={(e) => { e.preventDefault(); setStep(2); }} className="flex flex-col gap-4" noValidate>
                <Input label="Display name" value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Your name or pen name" required />
                <Input label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" autoComplete="email" required />
                <Input label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Minimum 8 characters" autoComplete="new-password" minLength={8} required hint="At least 8 characters." />
                <Button type="submit" fullWidth size="lg" className="mt-2" disabled={!displayName || !email || password.length < 8}>
                  Continue
                </Button>
              </form>
              <p className="text-center text-sm text-[var(--color-muted)] mt-6">
                Already a member?{" "}
                <a href="/login" className="text-[var(--color-teal)] hover:underline underline-offset-2 font-medium">Sign in</a>
              </p>
            </div>
          )}

          {/* Step 2: interests */}
          {step === 2 && (
            <div>
              <h2 className="font-[var(--font-display)] text-xl font-bold text-[var(--color-ink)] mb-1">Your fields of interest</h2>
              <p className="text-sm text-[var(--color-muted)] mb-6">Choose domains you'd like to explore. You can change this later.</p>
              <div className="flex flex-wrap gap-2 mb-8">
                {INTEREST_TAGS.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleInterest(tag)}
                    className={cn(
                      "px-3.5 py-1.5 text-sm rounded-full border transition-colors",
                      interests.includes(tag)
                        ? "bg-[var(--color-teal)] text-[var(--color-parchment)] border-[var(--color-teal)]"
                        : "border-[var(--color-border)] text-[var(--color-muted)] bg-white hover:border-[var(--color-teal)] hover:text-[var(--color-teal)]"
                    )}
                  >
                    {tag}
                  </button>
                ))}
              </div>
              <div className="flex gap-3">
                <Button variant="ghost" onClick={() => setStep(1)} fullWidth>Back</Button>
                <Button onClick={() => setStep(3)} fullWidth>Continue</Button>
              </div>
            </div>
          )}

          {/* Step 3: avatar glyph */}
          {step === 3 && (
            <div>
              <h2 className="font-[var(--font-display)] text-xl font-bold text-[var(--color-ink)] mb-1">Choose your glyph</h2>
              <p className="text-sm text-[var(--color-muted)] mb-6">This animal motif will represent you in the community.</p>
              <div className="grid grid-cols-5 gap-3 mb-8">
                {AVATAR_GLYPHS.map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setGlyph(g)}
                    title={g}
                    className={cn(
                      "w-full aspect-square flex items-center justify-center rounded-[var(--radius-lg)] border transition-all",
                      glyph === g
                        ? "border-[var(--color-gold)] bg-[var(--color-gold)]/15 text-[var(--color-ink)] scale-110 shadow-sm"
                        : "border-[var(--color-border)] bg-white text-[var(--color-muted)] hover:border-[var(--color-gold)]/50 hover:text-[var(--color-ink)]"
                    )}
                  >
                    <AnimalGlyph glyph={g} size={24} />
                  </button>
                ))}
              </div>
              <div className="flex gap-3">
                <Button variant="ghost" onClick={() => setStep(2)} fullWidth>Back</Button>
                <Button onClick={handleSubmit} loading={loading} fullWidth>Create account</Button>
              </div>
              <p className="text-center text-xs text-[var(--color-muted)] mt-4">
                By creating an account you agree to our{" "}
                <a href="/about#terms" className="underline underline-offset-2 hover:text-[var(--color-ink)]">terms</a>{" "}
                and{" "}
                <a href="/about#privacy" className="underline underline-offset-2 hover:text-[var(--color-ink)]">privacy policy</a>.
              </p>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
