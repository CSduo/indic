import React, { useRef, useState } from "react";
import { PenLine, Upload, FileText, BookOpen, AlertCircle } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/Button";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { useRequireAuth } from "@/lib/auth-context";
import { draftApi } from "@/lib/api";
import { SUPPORTED_IMPORT_FORMATS, MAX_UPLOAD_SIZE, MAX_UPLOAD_SIZE_MB } from "@/lib/constants";
import { formatFileSize } from "@/lib/utils";
import { toast } from "@/hooks/useToast";
import { cn } from "@/lib/utils";

type ImportState = "idle" | "validating" | "uploading" | "extracting" | "done" | "error";

export function WriterStartPage() {
  const { user } = useRequireAuth();
  const fileInput = useRef<HTMLInputElement>(null);
  const [importState, setImportState] = useState<ImportState>("idle");
  const [importFile, setImportFile]   = useState<File | null>(null);
  const [importError, setImportError] = useState("");
  const [creatingDraft, setCreatingDraft] = useState(false);

  if (!user) return null;

  async function handleNewDraft() {
    setCreatingDraft(true);
    try {
      const draft = await draftApi.create({ title: "", status: "draft", sourceType: "scratch" });
      window.location.href = `/write/drafts/${draft.id}`;
    } catch {
      toast("Could not create draft. Please try again.", "error");
      setCreatingDraft(false);
    }
  }

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    validateAndImport(file);
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) validateAndImport(file);
  }

  async function validateAndImport(file: File) {
    setImportError("");
    const allowedMimes = SUPPORTED_IMPORT_FORMATS.map((f) => f.mime);
    const allowedExts  = SUPPORTED_IMPORT_FORMATS.map((f) => f.ext);
    const ext = "." + file.name.split(".").pop()?.toLowerCase();

    if (!allowedExts.includes(ext as any) && !allowedMimes.includes(file.type as any)) {
      setImportError(`Unsupported format. Accepted: ${allowedExts.join(", ")}`);
      return;
    }
    if (file.size > MAX_UPLOAD_SIZE) {
      setImportError(`File too large. Maximum is ${MAX_UPLOAD_SIZE_MB} MB.`);
      return;
    }

    setImportFile(file);
    setImportState("uploading");

    try {
      const result = await draftApi.importDocument(file);
      setImportState("done");
      if (result.warnings?.length) {
        toast(`Imported with notes: ${result.warnings[0]}`, "warning");
      } else {
        toast(`Imported ${result.wordCount.toLocaleString()} words.`, "success");
      }
      window.location.href = `/write/drafts/${result.draftId}`;
    } catch (err: any) {
      setImportState("error");
      setImportError(err?.message || "Import failed. Try DOCX, TXT, or Markdown.");
    }
  }

  const acceptStr = SUPPORTED_IMPORT_FORMATS.map((f) => f.ext).join(",");

  return (
    <AppShell>
      <div className="container py-10 max-w-2xl">
        <Breadcrumb crumbs={[{ label: "Write & Submit" }]} className="mb-8" />

        <h1 className="font-[var(--font-display)] text-3xl font-bold text-[var(--color-ink)] mb-2">
          Share your inquiry.
        </h1>
        <p className="text-[var(--color-muted)] mb-10 leading-relaxed">
          Write inside Ānvīkṣikī or upload a manuscript and refine it before submission.
        </p>

        {/* Options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          {/* Write from scratch */}
          <button
            onClick={handleNewDraft}
            disabled={creatingDraft}
            className="group flex flex-col gap-4 p-6 rounded-[var(--radius-xl)] border-2 border-[var(--color-border)] bg-white hover:border-[var(--color-gold)] hover:bg-[var(--color-parchment)] transition-all duration-200 text-left disabled:opacity-60"
          >
            <div className="w-12 h-12 flex items-center justify-center rounded-[var(--radius-lg)] bg-[var(--color-teal)]/10 text-[var(--color-teal)] group-hover:bg-[var(--color-gold)]/15 transition-colors">
              <PenLine size={22} />
            </div>
            <div>
              <h2 className="font-[var(--font-display)] font-semibold text-[var(--color-ink)] text-lg">Write in editor</h2>
              <p className="text-sm text-[var(--color-muted)] mt-1 leading-snug">
                Start with a blank canvas and write directly.
              </p>
            </div>
            {creatingDraft && <p className="text-xs text-[var(--color-muted)]">Creating draft…</p>}
          </button>

          {/* Upload document */}
          <div
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
            className="group flex flex-col gap-4 p-6 rounded-[var(--radius-xl)] border-2 border-dashed border-[var(--color-border)] bg-white hover:border-[var(--color-gold)] hover:bg-[var(--color-parchment)] transition-all duration-200 cursor-pointer"
            onClick={() => fileInput.current?.click()}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === "Enter" && fileInput.current?.click()}
            aria-label="Upload document"
          >
            <div className="w-12 h-12 flex items-center justify-center rounded-[var(--radius-lg)] bg-[var(--color-rust)]/10 text-[var(--color-rust)] group-hover:bg-[var(--color-gold)]/15 transition-colors">
              <Upload size={22} />
            </div>
            <div>
              <h2 className="font-[var(--font-display)] font-semibold text-[var(--color-ink)] text-lg">Upload document</h2>
              <p className="text-sm text-[var(--color-muted)] mt-1 leading-snug">
                Import a DOCX, TXT, Markdown, or PDF file.
              </p>
            </div>
            <p className="text-xs text-[var(--color-muted)]">
              Drag & drop or click · Max {MAX_UPLOAD_SIZE_MB} MB
            </p>
            <input
              ref={fileInput}
              type="file"
              accept={acceptStr}
              onChange={handleFileSelect}
              className="sr-only"
              aria-hidden="true"
            />
          </div>
        </div>

        {/* Import status */}
        {importFile && importState !== "idle" && (
          <div className={cn(
            "mb-6 p-4 rounded-[var(--radius-lg)] border",
            importState === "error" ? "bg-red-50 border-red-200" : "bg-[var(--color-parchment-dark)] border-[var(--color-border)]"
          )}>
            <div className="flex items-start gap-3">
              <FileText size={18} className="shrink-0 mt-0.5 text-[var(--color-muted)]" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-[var(--color-ink)] truncate">{importFile.name}</p>
                <p className="text-xs text-[var(--color-muted)]">{formatFileSize(importFile.size)}</p>
                {importState === "uploading" && <p className="text-xs text-[var(--color-teal)] mt-1">Importing and extracting text…</p>}
                {importState === "error" && <p className="text-xs text-red-600 mt-1">{importError}</p>}
              </div>
            </div>
          </div>
        )}

        {importError && importState === "idle" && (
          <div className="mb-6 flex items-start gap-2 p-3.5 rounded-[var(--radius-md)] bg-red-50 border border-red-200 text-sm text-red-700">
            <AlertCircle size={16} className="shrink-0 mt-0.5" />
            {importError}
          </div>
        )}

        {/* Image notice */}
        <div className="mb-8 flex items-start gap-3 p-4 rounded-[var(--radius-lg)] bg-[var(--color-parchment-dark)] border border-[var(--color-border)]">
          <AlertCircle size={16} className="shrink-0 mt-0.5 text-[var(--color-muted)]" />
          <p className="text-xs text-[var(--color-muted)] leading-relaxed">
            <strong className="text-[var(--color-ink)]">Images are not extracted automatically.</strong>{" "}
            After import, place images, links, quotes, and formatting manually inside the editor.
          </p>
        </div>

        {/* Supported formats */}
        <div className="mb-8">
          <p className="text-xs font-medium text-[var(--color-muted)] mb-2">Supported formats</p>
          <div className="flex flex-wrap gap-2">
            {SUPPORTED_IMPORT_FORMATS.map((f) => (
              <span key={f.ext} className="text-xs px-2.5 py-1 rounded-full border border-[var(--color-border)] bg-white text-[var(--color-muted)]">
                {f.label}
              </span>
            ))}
          </div>
        </div>

        {/* More options */}
        <div className="flex flex-wrap gap-3">
          {user && (
            <Button as="a" href="/account/drafts" variant="ghost" size="sm" icon={<FileText size={15} />}>
              Continue a draft
            </Button>
          )}
          <Button as="a" href="/about#guidelines" variant="ghost" size="sm" icon={<BookOpen size={15} />}>
            Submission guidelines
          </Button>
        </div>
      </div>
    </AppShell>
  );
}
