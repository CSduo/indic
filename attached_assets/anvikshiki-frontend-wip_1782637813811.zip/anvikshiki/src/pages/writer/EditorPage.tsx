import React, { useCallback, useEffect, useRef, useState } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Bold, Italic, Link2, List, ListOrdered, Quote,
  Image, Minus, ArrowLeft, MoreHorizontal, Eye, Send, Check, AlertCircle
} from "lucide-react";
import { useRequireAuth } from "@/lib/auth-context";
import { draftApi } from "@/lib/api";
import { countWords, estimateReadingTime, saveDraftBackup } from "@/lib/utils";
import { toast } from "@/hooks/useToast";
import { cn } from "@/lib/utils";

type SaveState = "saved" | "saving" | "error" | "offline";

export function EditorPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useRequireAuth();
  const qc = useQueryClient();

  const [title, setTitle]       = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [body, setBody]         = useState("");
  const [saveState, setSaveState] = useState<SaveState>("saved");
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [wordCount, setWordCount] = useState(0);
  const bodyRef = useRef<HTMLTextAreaElement>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Fetch draft
  const { data: draft, isLoading } = useQuery({
    queryKey: ["draft", id],
    queryFn: () => draftApi.get(id!),
    enabled: !!id && !!user,
  });

  // Populate from fetched draft
  useEffect(() => {
    if (draft) {
      setTitle(draft.title || "");
      setSubtitle(draft.subtitle || "");
      setBody(draft.plainText || "");
      setWordCount(draft.wordCount || 0);
    }
  }, [draft]);

  // Autosave
  const save = useCallback(
    async (t: string, s: string, b: string) => {
      if (!id) return;
      setSaveState("saving");
      try {
        const wc = countWords(b);
        setWordCount(wc);
        await draftApi.update(id, {
          title: t,
          subtitle: s,
          plainText: b,
          wordCount: wc,
          readingTime: parseInt(estimateReadingTime(wc)),
          lastSavedAt: new Date().toISOString(),
        });
        setSaveState("saved");
        setLastSaved(new Date());
        saveDraftBackup({ draftId: id, title: t, content: b, savedAt: new Date().toISOString() });
        qc.invalidateQueries({ queryKey: ["drafts"] });
      } catch {
        setSaveState("error");
      }
    },
    [id, qc]
  );

  // Debounced autosave on content change
  useEffect(() => {
    if (!draft) return; // don't save before first load
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => save(title, subtitle, body), 2000);
    return () => { if (saveTimer.current) clearTimeout(saveTimer.current); };
  }, [title, subtitle, body]);

  // Online/offline detection
  useEffect(() => {
    const goOnline  = () => { if (saveState === "offline") setSaveState("saved"); };
    const goOffline = () => setSaveState("offline");
    window.addEventListener("online",  goOnline);
    window.addEventListener("offline", goOffline);
    return () => { window.removeEventListener("online", goOnline); window.removeEventListener("offline", goOffline); };
  }, [saveState]);

  function insertFormat(before: string, after = "") {
    const el = bodyRef.current;
    if (!el) return;
    const start = el.selectionStart;
    const end   = el.selectionEnd;
    const selected = body.slice(start, end);
    const next = body.slice(0, start) + before + selected + after + body.slice(end);
    setBody(next);
    setTimeout(() => {
      el.selectionStart = start + before.length;
      el.selectionEnd   = end + before.length;
      el.focus();
    }, 0);
  }

  const saveStateLabel = {
    saved:   <><Check size={12} /> Saved</>,
    saving:  <>Saving…</>,
    error:   <><AlertCircle size={12} className="text-red-500" /> Error saving</>,
    offline: <><AlertCircle size={12} className="text-amber-500" /> Offline</>,
  }[saveState];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Top bar */}
      <header className="flex items-center gap-3 px-4 md:px-6 h-14 border-b border-[var(--color-border)] shrink-0 sticky top-0 bg-white z-20">
        <a href="/account/drafts" className="flex items-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors" aria-label="Back to drafts">
          <ArrowLeft size={16} /> Drafts
        </a>

        <div className="flex-1 flex items-center justify-center gap-3">
          <span className="text-xs text-[var(--color-muted)] flex items-center gap-1.5">{saveStateLabel}</span>
        </div>

        <div className="flex items-center gap-2">
          <a href={`/write/drafts/${id}/preview`} className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-ink)] border border-[var(--color-border)] rounded-full hover:bg-[var(--color-parchment)] transition-all">
            <Eye size={14} /> Preview
          </a>
          <a href={`/write/drafts/${id}/metadata`} className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium bg-[var(--color-gold)] text-[var(--color-ink)] rounded-full hover:bg-[var(--color-gold-light)] transition-colors">
            <Send size={14} /> Next
          </a>
        </div>
      </header>

      {/* Formatting toolbar */}
      <div className="flex items-center gap-0.5 px-4 md:px-6 py-2 border-b border-[var(--color-border)] overflow-x-auto shrink-0 bg-[var(--color-parchment)]">
        {[
          { icon: <Bold size={14} />,         title: "Bold",          action: () => insertFormat("**", "**") },
          { icon: <Italic size={14} />,       title: "Italic",        action: () => insertFormat("_", "_") },
          { icon: <Link2 size={14} />,        title: "Link",          action: () => insertFormat("[", "](url)") },
          { icon: <Quote size={14} />,        title: "Quote",         action: () => insertFormat("\n> ") },
          { icon: <List size={14} />,         title: "Bullet list",   action: () => insertFormat("\n- ") },
          { icon: <ListOrdered size={14} />,  title: "Numbered list", action: () => insertFormat("\n1. ") },
          { icon: <Minus size={14} />,        title: "Divider",       action: () => insertFormat("\n---\n") },
          { icon: <Image size={14} />,        title: "Image",         action: () => insertFormat("![alt text](") + ")" },
        ].map((tool) => (
          <button
            key={tool.title}
            onClick={tool.action}
            title={tool.title}
            className="p-2 rounded hover:bg-[var(--color-parchment-dark)] text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors"
          >
            {tool.icon}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-3 text-xs text-[var(--color-muted)] shrink-0 pl-4 border-l border-[var(--color-border)]">
          <span>{wordCount.toLocaleString()} words</span>
          {wordCount > 0 && <span>{estimateReadingTime(wordCount)}</span>}
        </div>
      </div>

      {/* Editor body */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 md:px-6 py-10 flex flex-col gap-4">
          {/* Title */}
          <textarea
            value={title}
            onChange={(e) => { setTitle(e.target.value); e.target.style.height = "auto"; e.target.style.height = e.target.scrollHeight + "px"; }}
            placeholder="Title"
            rows={1}
            className="w-full resize-none outline-none font-[var(--font-display)] text-3xl md:text-4xl font-bold text-[var(--color-ink)] placeholder:text-[var(--color-border)] leading-tight bg-transparent overflow-hidden"
            aria-label="Essay title"
          />
          {/* Subtitle */}
          <textarea
            value={subtitle}
            onChange={(e) => { setSubtitle(e.target.value); e.target.style.height = "auto"; e.target.style.height = e.target.scrollHeight + "px"; }}
            placeholder="Add a subtitle…"
            rows={1}
            className="w-full resize-none outline-none font-[var(--font-display)] text-xl text-[var(--color-muted)] placeholder:text-[var(--color-border)] leading-snug bg-transparent overflow-hidden"
            aria-label="Essay subtitle"
          />
          {/* Divider */}
          <div className="border-t border-[var(--color-border)] my-2" aria-hidden="true" />
          {/* Body */}
          <textarea
            ref={bodyRef}
            value={body}
            onChange={(e) => { setBody(e.target.value); e.target.style.height = "auto"; e.target.style.height = e.target.scrollHeight + "px"; }}
            placeholder="Start writing your essay…"
            rows={20}
            className="w-full resize-none outline-none font-[var(--font-display)] text-lg text-[var(--color-ink)] placeholder:text-[var(--color-border)] leading-relaxed bg-transparent"
            aria-label="Essay body"
            style={{ minHeight: "60vh" }}
          />
        </div>
      </div>
    </div>
  );
}
