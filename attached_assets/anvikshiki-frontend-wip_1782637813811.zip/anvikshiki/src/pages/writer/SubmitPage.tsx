import React, { useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Check, AlertCircle, Send } from "lucide-react";
import { useRequireAuth } from "@/lib/auth-context";
import { draftApi } from "@/lib/api";
import { Button } from "@/components/ui/Button";
import { toast } from "@/hooks/useToast";
import { cn } from "@/lib/utils";

export function SubmitPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useRequireAuth();
  const [submitting, setSubmitting] = useState(false);
  const [submissionId, setSubmissionId] = useState<string | null>(null);

  const { data: draft } = useQuery({
    queryKey: ["draft", id],
    queryFn: () => draftApi.get(id!),
    enabled: !!id && !!user,
  });

  const checklist = [
    { label: "Content is present",            ok: !!(draft?.plainText && draft.plainText.trim().length > 100) },
    { label: "Title is set",                  ok: !!(draft?.title?.trim()) },
    { label: "Draft is not already submitted", ok: draft?.status !== "submitted" },
  ];

  const canSubmit = checklist.every((c) => c.ok) && !submitting;

  async function handleSubmit() {
    if (!id) return;
    setSubmitting(true);
    try {
      const submission = await draftApi.submit(id, {});
      setSubmissionId(submission.id);
      toast("Submission received. Thank you.", "success");
    } catch (err: any) {
      toast(err?.message || "Submission failed. Please try again.", "error");
      setSubmitting(false);
    }
  }

  if (!user) return null;

  // Success state
  if (submissionId) {
    return (
      <div className="min-h-screen bg-[var(--color-parchment)] flex items-center justify-center p-6">
        <div className="max-w-md w-full text-center">
          <div className="w-16 h-16 rounded-full bg-[var(--color-teal)] flex items-center justify-center text-[var(--color-parchment)] mx-auto mb-6">
            <Check size={28} />
          </div>
          <h1 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-ink)] mb-2">Submission received</h1>
          <p className="text-sm text-[var(--color-muted)] mb-2">Reference: <code className="font-mono text-xs bg-[var(--color-parchment-dark)] px-2 py-0.5 rounded">{submissionId}</code></p>
          <p className="text-sm text-[var(--color-muted)] leading-relaxed mb-8">
            Our editorial team will review your work and respond by email. You can track its status in your submissions dashboard.
          </p>
          <div className="flex flex-col gap-3">
            <Button as="a" href="/account/submissions" variant="primary" fullWidth>Track status</Button>
            <Button as="a" href="/" variant="ghost" fullWidth>Return to journal</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--color-parchment)]">
      <header className="sticky top-0 bg-[var(--color-parchment)]/95 backdrop-blur-sm border-b border-[var(--color-border)] z-20">
        <div className="flex items-center gap-3 px-4 md:px-6 h-14">
          <a href={`/write/drafts/${id}/metadata`} className="flex items-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-ink)]">
            <ArrowLeft size={16} /> Metadata
          </a>
          <div className="flex-1 text-center">
            <span className="text-sm font-medium text-[var(--color-ink)]">Submit for review</span>
          </div>
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 md:px-6 py-12">
        <h1 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-ink)] mb-2">Ready to submit?</h1>
        <p className="text-sm text-[var(--color-muted)] mb-8 leading-relaxed">
          Review the checklist below. Once submitted, editors will review your work and contact you by email.
          You can still view your draft while it is under review.
        </p>

        {/* Checklist */}
        <div className="flex flex-col gap-3 mb-8">
          {checklist.map((item) => (
            <div key={item.label} className={cn("flex items-center gap-3 p-3.5 rounded-[var(--radius-lg)] border", item.ok ? "border-green-200 bg-green-50" : "border-amber-200 bg-amber-50")}>
              <div className={cn("w-5 h-5 rounded-full flex items-center justify-center shrink-0", item.ok ? "bg-green-500 text-white" : "bg-amber-400 text-white")}>
                {item.ok ? <Check size={11} /> : <AlertCircle size={11} />}
              </div>
              <span className={cn("text-sm", item.ok ? "text-green-800" : "text-amber-800")}>{item.label}</span>
            </div>
          ))}
        </div>

        {/* Draft summary */}
        {draft && (
          <div className="mb-8 p-4 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white">
            <p className="text-xs font-medium text-[var(--color-muted)] mb-2">Submitting</p>
            <p className="font-[var(--font-display)] font-semibold text-[var(--color-ink)]">{draft.title || "Untitled"}</p>
            {draft.wordCount && <p className="text-xs text-[var(--color-muted)] mt-1">{draft.wordCount.toLocaleString()} words</p>}
          </div>
        )}

        <Button
          onClick={handleSubmit}
          disabled={!canSubmit}
          loading={submitting}
          fullWidth
          size="lg"
          icon={<Send size={18} />}
        >
          Submit for editorial review
        </Button>
        <p className="text-xs text-center text-[var(--color-muted)] mt-4">
          You can still edit your draft after submission if revision is requested.
        </p>
      </div>
    </div>
  );
}
