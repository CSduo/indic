import React, { useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Tag, X } from "lucide-react";
import { useRequireAuth } from "@/lib/auth-context";
import { draftApi } from "@/lib/api";
import { Button } from "@/components/ui/Button";
import { Input, Textarea, Select } from "@/components/ui/Input";
import { DOMAINS, CONTENT_TYPES } from "@/lib/constants";
import { toast } from "@/hooks/useToast";

export function MetadataPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useRequireAuth();

  const { data: draft } = useQuery({ queryKey: ["draft", id], queryFn: () => draftApi.get(id!), enabled: !!id && !!user });

  const [type, setType]       = useState("essay");
  const [domain, setDomain]   = useState("");
  const [tags, setTags]       = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [authorName, setAuthorName]   = useState(user?.displayName ?? "");
  const [authorEmail, setAuthorEmail] = useState(user?.email ?? "");
  const [authorBio, setAuthorBio]     = useState(user?.bio ?? "");
  const [affiliation, setAffiliation] = useState("");
  const [abstract, setAbstract]       = useState("");
  const [consent, setConsent]         = useState(false);

  function addTag() {
    const t = tagInput.trim();
    if (t && !tags.includes(t) && tags.length < 10) {
      setTags([...tags, t]);
      setTagInput("");
    }
  }

  function removeTag(tag: string) {
    setTags(tags.filter((t) => t !== tag));
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[var(--color-parchment)]">
      {/* Top bar */}
      <header className="sticky top-0 bg-[var(--color-parchment)]/95 backdrop-blur-sm border-b border-[var(--color-border)] z-20">
        <div className="flex items-center gap-3 px-4 md:px-6 h-14">
          <a href={`/write/drafts/${id}`} className="flex items-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-ink)]">
            <ArrowLeft size={16} /> Editor
          </a>
          <div className="flex-1 text-center">
            <span className="text-sm font-medium text-[var(--color-ink)]">Metadata & submission</span>
          </div>
          <a href={`/write/drafts/${id}/preview`} className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-[var(--color-muted)] border border-[var(--color-border)] rounded-full hover:bg-[var(--color-parchment-dark)] transition-all">
            Preview
          </a>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 md:px-6 py-10">
        <h1 className="font-[var(--font-display)] text-2xl font-bold text-[var(--color-ink)] mb-1">About your work</h1>
        <p className="text-sm text-[var(--color-muted)] mb-8">This information helps editors categorise and publish your work correctly.</p>

        <div className="flex flex-col gap-6">
          {/* Type */}
          <Select
            label="Content type"
            value={type}
            onChange={(e) => setType(e.target.value)}
            options={CONTENT_TYPES.map((t) => ({ value: t, label: t.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) }))}
          />

          {/* Domain */}
          <Select
            label="Primary domain"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            placeholder="Select a domain…"
            options={DOMAINS.map((d) => ({ value: d.slug, label: d.name }))}
          />

          {/* Abstract */}
          <Textarea
            label="Abstract / summary"
            value={abstract}
            onChange={(e) => setAbstract(e.target.value)}
            placeholder="A short summary of your work (up to 300 characters)…"
            maxLength={300}
            rows={3}
            hint={`${abstract.length}/300`}
          />

          {/* Tags */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-[var(--color-ink)]">Tags <span className="text-[var(--color-muted)] font-normal">(up to 10)</span></label>
            <div className="flex gap-2">
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addTag(); } }}
                placeholder="Add a tag and press Enter"
                className="flex-1 px-3.5 py-2.5 text-sm rounded-[var(--radius-md)] border border-[var(--color-border)] bg-white focus:outline-none focus:ring-2 focus:ring-[var(--color-gold)]"
              />
              <Button onClick={addTag} variant="ghost" size="sm" icon={<Tag size={14} />}>Add</Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-1">
                {tags.map((t) => (
                  <span key={t} className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded-full bg-[var(--color-parchment-dark)] text-[var(--color-ink)] border border-[var(--color-border)]">
                    {t}
                    <button onClick={() => removeTag(t)} className="text-[var(--color-muted)] hover:text-[var(--color-ink)]" aria-label={`Remove tag ${t}`}><X size={11} /></button>
                  </span>
                ))}
              </div>
            )}
          </div>

          <hr className="border-[var(--color-border)]" />
          <h2 className="font-[var(--font-display)] font-semibold text-[var(--color-ink)]">Author information</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input label="Display name" value={authorName} onChange={(e) => setAuthorName(e.target.value)} placeholder="Your name or pen name" />
            <Input label="Email" type="email" value={authorEmail} onChange={(e) => setAuthorEmail(e.target.value)} placeholder="For editorial correspondence" />
          </div>
          <Input label="Affiliation (optional)" value={affiliation} onChange={(e) => setAffiliation(e.target.value)} placeholder="University, organisation, or independent" />
          <Textarea label="Author bio" value={authorBio} onChange={(e) => setAuthorBio(e.target.value)} placeholder="A short bio (displayed with the published piece)" rows={3} />

          <hr className="border-[var(--color-border)]" />

          {/* Consent */}
          <label className="flex items-start gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={consent}
              onChange={(e) => setConsent(e.target.checked)}
              className="mt-0.5 accent-[var(--color-gold)] w-4 h-4"
            />
            <span className="text-sm text-[var(--color-ink)]">
              I confirm this is my original work and I have the rights to submit it. I agree to Ānvīkṣikī's{" "}
              <a href="/about#terms" className="underline underline-offset-2 hover:text-[var(--color-teal)]">submission terms</a>.
            </span>
          </label>

          {/* Actions */}
          <div className="flex flex-wrap gap-3 pt-2">
            <Button
              as="a"
              href={`/write/drafts/${id}/submit`}
              disabled={!consent || !domain || !authorName}
              variant="primary"
              size="lg"
            >
              Continue to submit
            </Button>
            <Button as="a" href={`/write/drafts/${id}/preview`} variant="ghost" size="lg">
              Preview first
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
