import { useCallback, useState } from "react";

export type ToastVariant = "success" | "error" | "info" | "warning";

export interface Toast {
  id: string;
  message: string;
  variant: ToastVariant;
}

let _toastFn: ((message: string, variant?: ToastVariant) => void) | null = null;

// Global imperative toast — call from anywhere outside React tree
export function toast(message: string, variant: ToastVariant = "info") {
  _toastFn?.(message, variant);
}

export function useToastState() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const add = useCallback((message: string, variant: ToastVariant = "info") => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { id, message, variant }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  const remove = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Register global imperactive accessor
  _toastFn = add;

  return { toasts, add, remove };
}
