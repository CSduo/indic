import React from "react";
import {
  PenLine, Upload, MessageSquarePlus,
  BookOpen, Send, FolderPlus, FileText,
} from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { useAuth } from "@/lib/auth-context";
import { AuthGate } from "@/components/auth/AuthGate";

interface CreateHubProps {
  open: boolean;
  onClose: () => void;
}

interface Option {
  icon: React.ReactNode;
  label: string;
  desc: string;
  href?: string;
  onClick?: () => void;
  requiresAuth?: boolean;
}

export function CreateHub({ open, onClose }: CreateHubProps) {
  const { user } = useAuth();
  const [showAuthGate, setShowAuthGate] = React.useState(false);
  const [authReason, setAuthReason] = React.useState("");

  function gated(reason: string, action: () => void) {
    if (!user) {
      setAuthReason(reason);
      setShowAuthGate(true);
      return;
    }
    action();
  }

  const options: Option[] = [
    {
      icon: <PenLine size={20} />,
      label: "Write an essay",
      desc: "Open the editor and start from scratch.",
      href: user ? "/write/new" : undefined,
      onClick: user ? undefined : () => gated("Create an account to write and save drafts.", () => {}),
    },
    {
      icon: <Upload size={20} />,
      label: "Upload a document",
      desc: "Import a DOCX, TXT, or Markdown file.",
      href: user ? "/write/import" : undefined,
      onClick: user ? undefined : () => gated("Create an account to import manuscripts.", () => {}),
    },
    {
      icon: <Send size={20} />,
      label: "Submit work",
      desc: "Send a piece to the editorial team.",
      href: user ? "/write" : undefined,
      onClick: user ? undefined : () => gated("Create an account to submit your work.", () => {}),
    },
    {
      icon: <MessageSquarePlus size={20} />,
      label: "Start a discussion",
      desc: "Share a thought with the community.",
      href: user ? "/community/discussions" : undefined,
      onClick: user ? undefined : () => gated("Create an account to join discussions.", () => {}),
    },
    {
      icon: <FileText size={20} />,
      label: "Continue a draft",
      desc: "Pick up where you left off.",
      href: user ? "/account/drafts" : undefined,
      onClick: user ? undefined : () => gated("Create an account to save drafts.", () => {}),
    },
    {
      icon: <FolderPlus size={20} />,
      label: "Create a collection",
      desc: "Organise saved items into a list.",
      href: user ? "/account/collections" : undefined,
      onClick: user ? undefined : () => gated("Create an account to build collections.", () => {}),
    },
    {
      icon: <BookOpen size={20} />,
      label: "Submission guidelines",
      desc: "Read editorial expectations before submitting.",
      href: "/about#guidelines",
    },
  ];

  return (
    <>
      <Modal open={open} onClose={onClose} title="Create & write" size="md">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {options.map((opt, i) => {
            const Element = opt.href ? "a" : "button";
            return (
              <Element
                key={i}
                href={opt.href}
                onClick={() => {
                  opt.onClick?.();
                  if (opt.href) onClose();
                }}
                className="group flex items-start gap-3 p-3.5 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white hover:border-[var(--color-gold)]/50 hover:bg-[var(--color-parchment)] transition-all duration-150 text-left cursor-pointer"
              >
                <div className="shrink-0 w-9 h-9 flex items-center justify-center rounded-[var(--radius-md)] bg-[var(--color-parchment-dark)] text-[var(--color-teal)] group-hover:bg-[var(--color-gold)]/15 group-hover:text-[var(--color-ink)] transition-colors">
                  {opt.icon}
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-[var(--color-ink)]">{opt.label}</p>
                  <p className="text-xs text-[var(--color-muted)] mt-0.5 leading-snug">{opt.desc}</p>
                </div>
              </Element>
            );
          })}
        </div>

        {!user && (
          <div className="mt-4 p-3.5 rounded-[var(--radius-lg)] bg-[var(--color-teal)]/8 border border-[var(--color-teal)]/20 text-sm text-[var(--color-teal)]">
            <strong>Sign in</strong> to save drafts, submit work, and join the community.{" "}
            <a href="/signup" className="underline underline-offset-2 hover:text-[var(--color-ink)] transition-colors" onClick={onClose}>
              Create account →
            </a>
          </div>
        )}
      </Modal>

      <AuthGate
        open={showAuthGate}
        onClose={() => setShowAuthGate(false)}
        reason={authReason}
      />
    </>
  );
}
