import React, { useState, useEffect } from "react";
import { Search, Plus, Menu, Bell, User, LogOut, ChevronDown } from "lucide-react";
import { useRoute, Link } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth-context";
import { NAV_LINKS, SITE_NAME } from "@/lib/constants";
import { CreateHub } from "@/components/plus/CreateHub";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";

interface HeaderProps {
  onMobileMenuOpen: () => void;
}

export function Header({ onMobileMenuOpen }: HeaderProps) {
  const { user, logout, isAdmin } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchValue, setSearchValue] = useState("");

  // Keyboard shortcut: / opens search, C opens create
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement).tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === "/" && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setSearchOpen(true);
      }
      if ((e.key === "c" || e.key === "C") && !e.ctrlKey && !e.metaKey) {
        setCreateOpen(true);
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  async function handleLogout() {
    setProfileOpen(false);
    await logout();
    window.location.href = "/";
  }

  return (
    <>
      <header
        className={cn(
          "fixed top-0 left-0 right-0 z-30 h-[var(--header-height)]",
          "flex items-center border-b transition-all duration-200",
          scrolled
            ? "bg-[var(--color-parchment)]/95 backdrop-blur-md border-[var(--color-border)] shadow-sm"
            : "bg-[var(--color-parchment)] border-transparent"
        )}
      >
        <div className="container flex items-center gap-4 h-full">
          {/* Logo */}
          <a
            href="/"
            className="flex items-center gap-2.5 shrink-0 hover:opacity-80 transition-opacity"
            aria-label="Ānvīkṣikī — home"
          >
            {/* Official emblem — place file at public/emblem.svg or public/emblem.png */}
            <img
              src="/emblem.svg"
              alt=""
              width={28}
              height={28}
              aria-hidden="true"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
            <span
              className="font-[var(--font-classical)] text-sm font-medium text-[var(--color-ink)] tracking-wide hidden sm:block"
              aria-hidden="true"
            >
              ĀNVĪKṢIKĪ
            </span>
          </a>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-0.5 ml-4" aria-label="Main navigation">
            {NAV_LINKS.map((link) => (
              <NavLink key={link.href} href={link.href} label={link.label} />
            ))}
            {isAdmin && (
              <NavLink href="/admin" label="Admin" />
            )}
          </nav>

          {/* Spacer */}
          <div className="flex-1" />

          {/* Search bar — desktop */}
          <div className="hidden md:flex items-center relative">
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className={cn(
                "flex items-center gap-2 text-sm text-[var(--color-muted)] border border-[var(--color-border)] rounded-full px-3.5 py-1.5",
                "hover:border-[var(--color-gold)]/50 hover:text-[var(--color-ink)] transition-all duration-150 bg-white min-w-[180px]",
                searchOpen && "ring-1 ring-[var(--color-gold)]"
              )}
            >
              <Search size={14} aria-hidden="true" />
              <span className="flex-1 text-left">Search…</span>
              <kbd className="text-[10px] opacity-50 font-mono">/</kbd>
            </button>

            {searchOpen && (
              <div className="absolute top-10 right-0 w-[360px] bg-white rounded-[var(--radius-lg)] border border-[var(--color-border)] shadow-[var(--shadow-modal)] z-50 p-2">
                <div className="flex items-center gap-2 px-2">
                  <Search size={14} className="text-[var(--color-muted)] shrink-0" />
                  <input
                    autoFocus
                    type="text"
                    placeholder="Search essays, papers, authors…"
                    value={searchValue}
                    onChange={(e) => setSearchValue(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && searchValue.trim()) {
                        window.location.href = `/search?q=${encodeURIComponent(searchValue.trim())}`;
                      }
                      if (e.key === "Escape") setSearchOpen(false);
                    }}
                    className="flex-1 outline-none text-sm text-[var(--color-ink)] placeholder:text-[var(--color-muted)] bg-transparent py-2"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Plus / create button */}
          <button
            onClick={() => setCreateOpen(true)}
            className="flex items-center justify-center w-8 h-8 rounded-full bg-[var(--color-gold)] hover:bg-[var(--color-gold-light)] text-[var(--color-ink)] transition-colors"
            aria-label="Create"
            title="Create (press C)"
          >
            <Plus size={16} />
          </button>

          {/* Auth area */}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setProfileOpen((p) => !p)}
                className="flex items-center gap-2 p-1 rounded-full hover:bg-[var(--color-parchment-dark)] transition-colors"
                aria-label="Account menu"
                aria-expanded={profileOpen}
              >
                {user.avatarUrl ? (
                  <img
                    src={user.avatarUrl}
                    alt={user.displayName}
                    className="w-7 h-7 rounded-full object-cover border border-[var(--color-border)]"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-[var(--color-teal)] flex items-center justify-center text-[var(--color-parchment)]">
                    <AnimalGlyph glyph={user.avatarGlyph || "lotus"} size={16} />
                  </div>
                )}
                <ChevronDown size={12} className="text-[var(--color-muted)] hidden md:block" />
              </button>

              {profileOpen && (
                <div className="absolute top-10 right-0 w-52 bg-white rounded-[var(--radius-lg)] border border-[var(--color-border)] shadow-[var(--shadow-modal)] z-50 py-1.5 overflow-hidden">
                  <div className="px-4 py-2.5 border-b border-[var(--color-border)]">
                    <p className="text-sm font-medium text-[var(--color-ink)] truncate">{user.displayName}</p>
                    <p className="text-xs text-[var(--color-muted)] truncate">{user.email}</p>
                  </div>
                  {[
                    { href: "/account",             label: "Dashboard" },
                    { href: "/account/profile",     label: "Profile" },
                    { href: "/account/drafts",      label: "Drafts" },
                    { href: "/account/submissions", label: "Submissions" },
                    { href: "/account/saved",       label: "Saved items" },
                    ...(isAdmin ? [{ href: "/admin", label: "Admin panel" }] : []),
                  ].map((item) => (
                    <a
                      key={item.href}
                      href={item.href}
                      className="flex items-center px-4 py-2 text-sm text-[var(--color-ink)] hover:bg-[var(--color-parchment)] transition-colors"
                      onClick={() => setProfileOpen(false)}
                    >
                      {item.label}
                    </a>
                  ))}
                  <div className="border-t border-[var(--color-border)] mt-1 pt-1">
                    <button
                      onClick={handleLogout}
                      className="flex items-center gap-2 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
                    >
                      <LogOut size={14} aria-hidden="true" />
                      Sign out
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="hidden sm:flex items-center gap-2">
              <a href="/login" className="text-sm text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors px-2 py-1">
                Sign in
              </a>
              <a
                href="/signup"
                className="text-sm font-medium px-3.5 py-1.5 rounded-full bg-[var(--color-teal)] text-[var(--color-parchment)] hover:bg-[var(--color-teal)]/90 transition-colors"
              >
                Join
              </a>
            </div>
          )}

          {/* Mobile search */}
          <a href="/search" className="flex md:hidden items-center justify-center w-8 h-8 text-[var(--color-muted)] hover:text-[var(--color-ink)]" aria-label="Search">
            <Search size={18} />
          </a>

          {/* Mobile menu */}
          <button
            onClick={onMobileMenuOpen}
            className="flex md:hidden items-center justify-center w-8 h-8 text-[var(--color-muted)] hover:text-[var(--color-ink)]"
            aria-label="Open menu"
          >
            <Menu size={20} />
          </button>
        </div>
      </header>

      {/* Close overlay for profile dropdown */}
      {profileOpen && (
        <div
          className="fixed inset-0 z-20"
          onClick={() => setProfileOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Close overlay for search */}
      {searchOpen && (
        <div
          className="fixed inset-0 z-20"
          onClick={() => setSearchOpen(false)}
          aria-hidden="true"
        />
      )}

      <CreateHub open={createOpen} onClose={() => setCreateOpen(false)} />
    </>
  );
}

function NavLink({ href, label }: { href: string; label: string }) {
  const [isActive] = useRoute(href === "/" ? "/" : `${href}/*?`);
  return (
    <a
      href={href}
      className={cn(
        "px-3.5 py-1.5 text-sm rounded-full transition-colors",
        isActive
          ? "text-[var(--color-ink)] font-medium bg-[var(--color-parchment-dark)]"
          : "text-[var(--color-muted)] hover:text-[var(--color-ink)] hover:bg-[var(--color-parchment-dark)]"
      )}
    >
      {label}
    </a>
  );
}
