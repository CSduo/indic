import React, { useState } from "react";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import { AVATAR_GLYPHS, SITE_NAME, SITE_TAGLINE, SITE_DESCRIPTION } from "@/lib/constants";
import { newsletterApi } from "@/lib/api";
import { toast } from "@/hooks/useToast";
import { Button } from "@/components/ui/Button";

const FOOTER_COLS = [
  {
    heading: "Explore",
    links: [
      { label: "Essays",      href: "/essays" },
      { label: "Papers",      href: "/papers" },
      { label: "Themes",      href: "/explore" },
      { label: "Authors",     href: "/explore?view=authors" },
    ],
  },
  {
    heading: "Archive",
    links: [
      { label: "All Essays",   href: "/essays" },
      { label: "Collections",  href: "/explore?view=collections" },
      { label: "Timelines",    href: "/archive?view=timelines" },
      { label: "Maps",         href: "/archive?view=maps" },
    ],
  },
  {
    heading: "Community",
    links: [
      { label: "Discussions", href: "/community/discussions" },
      { label: "Events",      href: "/community/events" },
      { label: "Groups",      href: "/community/groups" },
      { label: "Contribute",  href: "/write" },
    ],
  },
  {
    heading: "About",
    links: [
      { label: "Our Vision",    href: "/about" },
      { label: "Editorial",     href: "/about#editorial" },
      { label: "Guidelines",    href: "/about#guidelines" },
      { label: "Contact",       href: "/contact" },
    ],
  },
];

export function Footer() {
  const [email, setEmail] = useState("");
  const [subscribing, setSubscribing] = useState(false);

  async function handleSubscribe(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribing(true);
    try {
      await newsletterApi.subscribe(email.trim());
      toast("Subscribed. You'll receive new essays and updates.", "success");
      setEmail("");
    } catch {
      toast("Could not subscribe. Try again.", "error");
    } finally {
      setSubscribing(false);
    }
  }

  return (
    <footer className="section-ink pt-14 pb-0">
      {/* Main footer grid */}
      <div className="container pb-12">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10">
          {/* Brand column */}
          <div className="md:col-span-1 flex flex-col gap-4">
            <div className="flex items-center gap-2.5">
              <img
                src="/emblem.svg"
                alt=""
                width={28}
                height={28}
                aria-hidden="true"
                className="opacity-80"
                onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
              />
              <span className="font-[var(--font-classical)] text-xs tracking-widest text-[var(--color-parchment)] opacity-80 uppercase">
                {SITE_NAME}
              </span>
            </div>
            <p className="text-xs text-[var(--color-parchment)]/50 leading-relaxed">
              {SITE_DESCRIPTION}
            </p>
            <div className="flex gap-3 mt-2">
              {/* Social links — configured via admin settings; shown as placeholders */}
              <a
                href="https://x.com/anvikshiki"
                aria-label="X / Twitter"
                className="w-7 h-7 flex items-center justify-center rounded-full border border-[var(--color-parchment)]/20 text-[var(--color-parchment)]/50 hover:text-[var(--color-parchment)] hover:border-[var(--color-parchment)]/50 transition-colors text-xs"
              >
                𝕏
              </a>
              <a
                href="https://instagram.com/anvikshiki"
                aria-label="Instagram"
                className="w-7 h-7 flex items-center justify-center rounded-full border border-[var(--color-parchment)]/20 text-[var(--color-parchment)]/50 hover:text-[var(--color-parchment)] hover:border-[var(--color-parchment)]/50 transition-colors text-xs"
              >
                IG
              </a>
            </div>
          </div>

          {/* Nav columns */}
          {FOOTER_COLS.map((col) => (
            <div key={col.heading} className="flex flex-col gap-3">
              <p className="eyebrow text-[var(--color-gold)] opacity-80">{col.heading}</p>
              <ul className="flex flex-col gap-2">
                {col.links.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="text-sm text-[var(--color-parchment)]/60 hover:text-[var(--color-parchment)] transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter */}
        <div className="mt-10 pt-8 border-t border-[var(--color-parchment)]/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <p className="text-sm font-medium text-[var(--color-parchment)]/80">
              Receive new essays & updates
            </p>
            <p className="text-xs text-[var(--color-parchment)]/40 mt-0.5">
              No noise. Only worthy inquiry.
            </p>
          </div>
          <form
            onSubmit={handleSubscribe}
            className="flex gap-2 w-full sm:w-auto"
          >
            <input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="flex-1 sm:w-56 px-3.5 py-2 text-sm rounded-[var(--radius-md)] bg-[var(--color-parchment)]/10 border border-[var(--color-parchment)]/20 text-[var(--color-parchment)] placeholder:text-[var(--color-parchment)]/30 focus:outline-none focus:ring-1 focus:ring-[var(--color-gold)]"
            />
            <Button type="submit" variant="primary" size="sm" loading={subscribing}>
              Subscribe
            </Button>
          </form>
        </div>
      </div>

      {/* Ornamental animal strip */}
      <div className="border-t border-[var(--color-gold)]/20 py-4 overflow-hidden">
        <div className="flex items-center justify-center gap-6 opacity-30" aria-hidden="true">
          {AVATAR_GLYPHS.map((glyph) => (
            <AnimalGlyph
              key={glyph}
              glyph={glyph}
              size={20}
              color="var(--color-gold)"
            />
          ))}
        </div>
      </div>

      {/* Legal */}
      <div className="border-t border-[var(--color-parchment)]/5 py-3">
        <div className="container flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[var(--color-parchment)]/30">
          <p>© {new Date().getFullYear()} Ānvīkṣikī. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="/about#privacy" className="hover:text-[var(--color-parchment)]/60 transition-colors">Privacy</a>
            <a href="/about#terms" className="hover:text-[var(--color-parchment)]/60 transition-colors">Terms</a>
            <a href="/contact" className="hover:text-[var(--color-parchment)]/60 transition-colors">Contact</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
