import React, { useEffect } from "react";
import { X, ChevronRight, PenLine } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth-context";
import { NAV_LINKS, SITE_NAME, SITE_TAGLINE } from "@/lib/constants";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";

interface MobileDrawerProps {
  open: boolean;
  onClose: () => void;
}

export function MobileDrawer({ open, onClose }: MobileDrawerProps) {
  const { user, logout, isAdmin } = useAuth();

  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    if (open) document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  async function handleLogout() {
    onClose();
    await logout();
    window.location.href = "/";
  }

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 bg-[var(--color-ink)]/50 z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            aria-hidden="true"
          />

          {/* Drawer */}
          <motion.div
            className="fixed top-0 right-0 bottom-0 w-[85vw] max-w-sm bg-[var(--color-parchment)] z-50 flex flex-col shadow-[var(--shadow-modal)] overflow-y-auto"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            role="dialog"
            aria-modal="true"
            aria-label="Navigation menu"
          >
            {/* Top bar */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--color-border)] shrink-0">
              <div>
                <p className="font-[var(--font-classical)] text-xs tracking-widest text-[var(--color-teal)] uppercase">
                  {SITE_NAME}
                </p>
                <p className="text-xs text-[var(--color-muted)] mt-0.5">{SITE_TAGLINE}</p>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-[var(--color-parchment-dark)] text-[var(--color-muted)] transition-colors"
                aria-label="Close menu"
              >
                <X size={18} />
              </button>
            </div>

            {/* Auth state */}
            {user ? (
              <a
                href="/account"
                onClick={onClose}
                className="flex items-center gap-3 px-5 py-4 bg-[var(--color-teal)]/8 border-b border-[var(--color-border)]"
              >
                <div className="w-10 h-10 rounded-full bg-[var(--color-teal)] flex items-center justify-center text-[var(--color-parchment)] shrink-0">
                  {user.avatarUrl ? (
                    <img src={user.avatarUrl} alt="" className="w-10 h-10 rounded-full object-cover" />
                  ) : (
                    <AnimalGlyph glyph={user.avatarGlyph || "lotus"} size={20} />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[var(--color-ink)] truncate">{user.displayName}</p>
                  <p className="text-xs text-[var(--color-muted)] truncate">{user.email}</p>
                </div>
                <ChevronRight size={14} className="text-[var(--color-muted)] shrink-0" />
              </a>
            ) : (
              <div className="px-5 py-4 flex gap-2 border-b border-[var(--color-border)]">
                <a
                  href="/login"
                  onClick={onClose}
                  className="flex-1 text-center py-2 text-sm border border-[var(--color-border)] rounded-[var(--radius-md)] text-[var(--color-ink)] hover:bg-[var(--color-parchment-dark)] transition-colors"
                >
                  Sign in
                </a>
                <a
                  href="/signup"
                  onClick={onClose}
                  className="flex-1 text-center py-2 text-sm bg-[var(--color-gold)] rounded-[var(--radius-md)] text-[var(--color-ink)] font-medium hover:bg-[var(--color-gold-light)] transition-colors"
                >
                  Join
                </a>
              </div>
            )}

            {/* Quick create */}
            <a
              href={user ? "/write" : "/signup"}
              onClick={onClose}
              className="flex items-center gap-3 px-5 py-3.5 bg-[var(--color-gold)]/10 border-b border-[var(--color-border)] hover:bg-[var(--color-gold)]/20 transition-colors"
            >
              <PenLine size={16} className="text-[var(--color-ink)] shrink-0" />
              <span className="text-sm font-medium text-[var(--color-ink)]">Write & submit</span>
              <ChevronRight size={14} className="text-[var(--color-muted)] ml-auto shrink-0" />
            </a>

            {/* Navigation */}
            <nav className="flex-1 px-3 py-4" aria-label="Mobile navigation">
              <p className="eyebrow px-2 mb-3">Explore</p>
              {NAV_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={onClose}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-[var(--radius-md)] text-sm text-[var(--color-ink)] hover:bg-[var(--color-parchment-dark)] transition-colors"
                >
                  {link.label}
                  <ChevronRight size={14} className="text-[var(--color-muted)] ml-auto" />
                </a>
              ))}

              {user && (
                <>
                  <p className="eyebrow px-2 mb-3 mt-5">My account</p>
                  {[
                    { href: "/account",             label: "Dashboard" },
                    { href: "/account/drafts",      label: "Drafts" },
                    { href: "/account/submissions", label: "Submissions" },
                    { href: "/account/saved",       label: "Saved items" },
                    { href: "/account/profile",     label: "Profile" },
                  ].map((item) => (
                    <a
                      key={item.href}
                      href={item.href}
                      onClick={onClose}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-[var(--radius-md)] text-sm text-[var(--color-ink)] hover:bg-[var(--color-parchment-dark)] transition-colors"
                    >
                      {item.label}
                      <ChevronRight size={14} className="text-[var(--color-muted)] ml-auto" />
                    </a>
                  ))}
                  {isAdmin && (
                    <a
                      href="/admin"
                      onClick={onClose}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-[var(--radius-md)] text-sm text-[var(--color-teal)] font-medium hover:bg-[var(--color-parchment-dark)] transition-colors"
                    >
                      Admin panel
                      <ChevronRight size={14} className="ml-auto" />
                    </a>
                  )}
                </>
              )}

              <p className="eyebrow px-2 mb-3 mt-5">Platform</p>
              {[
                { href: "/about",     label: "About" },
                { href: "/contact",   label: "Contact" },
                { href: "/support",   label: "Support" },
              ].map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={onClose}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-[var(--radius-md)] text-sm text-[var(--color-ink)] hover:bg-[var(--color-parchment-dark)] transition-colors"
                >
                  {item.label}
                  <ChevronRight size={14} className="text-[var(--color-muted)] ml-auto" />
                </a>
              ))}
            </nav>

            {/* Sign out */}
            {user && (
              <div className="shrink-0 p-4 border-t border-[var(--color-border)]">
                <button
                  onClick={handleLogout}
                  className="w-full text-sm text-red-600 py-2.5 rounded-[var(--radius-md)] hover:bg-red-50 transition-colors"
                >
                  Sign out
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
