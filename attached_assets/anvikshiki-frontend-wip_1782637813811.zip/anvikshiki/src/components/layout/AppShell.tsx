import React, { useState, useEffect } from "react";
import { Header } from "./Header";
import { MobileDrawer } from "./MobileDrawer";
import { Footer } from "./Footer";
import { ToastContainer } from "@/components/ui/Toast";
import { useToastState } from "@/hooks/useToast";

interface AppShellProps {
  children: React.ReactNode;
  hideFooter?: boolean;
  fullBleed?: boolean; // bypasses default padding-top so hero can sit behind header
}

export function AppShell({ children, hideFooter = false, fullBleed = false }: AppShellProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const { toasts, remove } = useToastState();

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[var(--color-parchment)]">
      <Header onMobileMenuOpen={() => setDrawerOpen(true)} />
      <MobileDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} />

      <main
        id="main-content"
        className={fullBleed ? "flex-1" : "flex-1 pt-[var(--header-height)]"}
      >
        {children}
      </main>

      {!hideFooter && <Footer />}

      <ToastContainer toasts={toasts} onRemove={remove} />
    </div>
  );
}
