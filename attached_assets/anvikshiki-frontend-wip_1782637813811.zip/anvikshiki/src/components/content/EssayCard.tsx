import React, { useState } from "react";
import { Bookmark, BookmarkCheck } from "lucide-react";
import { cn, formatDate, estimateReadingTime } from "@/lib/utils";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import { DOMAINS } from "@/lib/constants";
import type { Article } from "@/lib/api";

interface EssayCardProps {
  article: Article;
  onSave?: (id: string) => void;
  saved?: boolean;
  featured?: boolean;
  layout?: "grid" | "list";
  className?: string;
}

export function EssayCard({
  article,
  onSave,
  saved = false,
  featured = false,
  layout = "grid",
  className,
}: EssayCardProps) {
  const [isSaved, setIsSaved] = useState(saved);
  const domain = DOMAINS.find((d) => d.slug === article.domain);
  const readingTime = article.readingTime
    ? `${article.readingTime} min read`
    : article.wordCount
    ? estimateReadingTime(article.wordCount)
    : null;

  function handleSave(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    setIsSaved((prev) => !prev);
    onSave?.(article.id);
  }

  if (layout === "list") {
    return (
      <a
        href={`/essays/${article.slug}`}
        className={cn(
          "group flex gap-4 p-4 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white",
          "hover:border-[var(--color-gold)]/50 hover:shadow-[var(--shadow-card)] transition-all duration-200",
          className
        )}
      >
        {domain && (
          <div className="shrink-0 w-10 h-10 flex items-center justify-center rounded-full bg-[var(--color-parchment-dark)] text-[var(--color-teal)] mt-0.5">
            <AnimalGlyph glyph={domain.glyph} size={20} />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <p className="eyebrow mb-1">{domain?.name ?? article.domain}</p>
          <h3 className="font-[var(--font-display)] font-semibold text-base text-[var(--color-ink)] group-hover:text-[var(--color-teal)] transition-colors line-clamp-2">
            {article.title}
          </h3>
          {article.subtitle && (
            <p className="text-sm text-[var(--color-muted)] mt-0.5 line-clamp-1">{article.subtitle}</p>
          )}
          <div className="flex items-center gap-3 mt-2 text-xs text-[var(--color-muted)]">
            <span>{article.authorName}</span>
            <span>·</span>
            <span>{formatDate(article.publishedAt)}</span>
            {readingTime && <><span>·</span><span>{readingTime}</span></>}
          </div>
        </div>
        <button
          onClick={handleSave}
          className="shrink-0 p-1.5 rounded hover:bg-[var(--color-parchment-dark)] text-[var(--color-muted)] hover:text-[var(--color-gold)] transition-colors self-start"
          aria-label={isSaved ? "Remove bookmark" : "Save essay"}
        >
          {isSaved ? <BookmarkCheck size={16} className="text-[var(--color-gold)]" /> : <Bookmark size={16} />}
        </button>
      </a>
    );
  }

  return (
    <a
      href={`/essays/${article.slug}`}
      className={cn(
        "group card flex flex-col",
        featured ? "md:flex-row md:items-stretch" : "",
        className
      )}
    >
      {/* Cover image */}
      {article.coverImage && (
        <div
          className={cn(
            "bg-[var(--color-parchment-dark)] overflow-hidden flex-shrink-0",
            featured
              ? "md:w-2/5 h-52 md:h-auto rounded-t-[var(--radius-lg)] md:rounded-l-[var(--radius-lg)] md:rounded-tr-none"
              : "h-40 rounded-t-[var(--radius-lg)]"
          )}
        >
          <img
            src={article.coverImage}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-500"
          />
        </div>
      )}

      {/* Content */}
      <div className="flex flex-col flex-1 p-5 gap-3">
        {/* Domain + save */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {domain && (
              <AnimalGlyph
                glyph={domain.glyph}
                size={16}
                className="text-[var(--color-rust)]"
              />
            )}
            <span className="eyebrow">{domain?.name ?? article.domain}</span>
          </div>
          <button
            onClick={handleSave}
            className="p-1 rounded hover:bg-[var(--color-parchment-dark)] text-[var(--color-muted)] hover:text-[var(--color-gold)] transition-colors"
            aria-label={isSaved ? "Remove bookmark" : "Save essay"}
          >
            {isSaved
              ? <BookmarkCheck size={15} className="text-[var(--color-gold)]" />
              : <Bookmark size={15} />
            }
          </button>
        </div>

        {/* Title */}
        <div>
          <h3
            className={cn(
              "font-[var(--font-display)] font-semibold text-[var(--color-ink)] group-hover:text-[var(--color-teal)] transition-colors leading-snug",
              featured ? "text-xl md:text-2xl" : "text-base line-clamp-2"
            )}
          >
            {article.title}
          </h3>
          {article.subtitle && (
            <p className="text-sm text-[var(--color-muted)] mt-1 line-clamp-2">
              {article.subtitle}
            </p>
          )}
        </div>

        {/* Excerpt */}
        {article.excerpt && featured && (
          <p className="text-sm text-[var(--color-ink)]/70 line-clamp-3 leading-relaxed">
            {article.excerpt}
          </p>
        )}

        {/* Meta */}
        <div className="flex items-center gap-2 text-xs text-[var(--color-muted)] mt-auto pt-2 border-t border-[var(--color-border)]">
          <span>{article.authorName}</span>
          <span>·</span>
          <span>{formatDate(article.publishedAt)}</span>
          {readingTime && <><span>·</span><span>{readingTime}</span></>}
        </div>
      </div>
    </a>
  );
}
