import React from "react";
import { ArrowRight } from "lucide-react";
import { cn, getDomainAccent } from "@/lib/utils";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import type { Domain } from "@/lib/constants";

interface DomainCardProps {
  domain: Domain;
  contentCount?: number;
  compact?: boolean;
  className?: string;
}

export function DomainCard({
  domain,
  contentCount,
  compact = false,
  className,
}: DomainCardProps) {
  const accent = getDomainAccent(domain.slug);

  if (compact) {
    return (
      <a
        href={`/domains/${domain.slug}`}
        className={cn(
          "group flex flex-col items-center gap-2 p-4 rounded-[var(--radius-lg)] border border-[var(--color-border)] bg-white",
          "hover:border-[var(--color-gold)]/50 hover:bg-[var(--color-parchment)] transition-all duration-200 text-center",
          className
        )}
      >
        <div
          className="w-10 h-10 flex items-center justify-center rounded-full"
          style={{ backgroundColor: `${accent}18`, color: accent }}
        >
          <AnimalGlyph glyph={domain.glyph} size={20} />
        </div>
        <span className="text-xs font-medium text-[var(--color-ink)] leading-tight">{domain.name}</span>
      </a>
    );
  }

  return (
    <a
      href={`/domains/${domain.slug}`}
      className={cn(
        "group card p-5 flex flex-col gap-3",
        className
      )}
    >
      {/* Glyph */}
      <div
        className="w-12 h-12 flex items-center justify-center rounded-full transition-transform group-hover:scale-110 duration-200"
        style={{ backgroundColor: `${accent}18`, color: accent }}
      >
        <AnimalGlyph glyph={domain.glyph} size={24} />
      </div>

      {/* Title */}
      <div>
        <h3 className="font-[var(--font-display)] font-semibold text-[var(--color-ink)] group-hover:text-[var(--color-teal)] transition-colors">
          {domain.name}
        </h3>
        <p className="text-sm text-[var(--color-muted)] mt-1 line-clamp-2 leading-relaxed">
          {domain.description}
        </p>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between mt-auto pt-3 border-t border-[var(--color-border)]">
        {typeof contentCount === "number" ? (
          <span className="text-xs text-[var(--color-muted)]">
            {contentCount === 0 ? "No content yet" : `${contentCount} item${contentCount === 1 ? "" : "s"}`}
          </span>
        ) : (
          <span />
        )}
        <span className="text-[var(--color-gold)] group-hover:translate-x-1 transition-transform duration-200">
          <ArrowRight size={16} />
        </span>
      </div>
    </a>
  );
}
