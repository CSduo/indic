import React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/Button";

export type HeroVariant =
  | "knowledge-journey"
  | "archive-scribe"
  | "culture-music"
  | "wanderer"
  | "myth-symbol"
  | "community"
  | "science"
  | "geopolitics";

interface HeroAction {
  label: string;
  href?: string;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "outline";
}

interface HeroPanelProps {
  variant?: HeroVariant;
  eyebrow?: string;
  headline: string;
  subline?: string;
  actions?: HeroAction[];
  dark?: boolean;
  className?: string;
  minHeight?: string;
  illustrationSrc?: string;
}

// Fallback gradient backgrounds per hero variant — the project's own illustration assets
// should be placed in public/images/heroes/ and referenced via illustrationSrc.
const VARIANT_GRADIENTS: Record<HeroVariant, string> = {
  "knowledge-journey": "from-[#0F1B1F] via-[#16455F] to-[#1A3048]",
  "archive-scribe":    "from-[#1A1208] via-[#2D2010] to-[#16455F]",
  "culture-music":     "from-[#2A0F0F] via-[#3D1A0A] to-[#16455F]",
  "wanderer":          "from-[#0A1A0F] via-[#16455F] to-[#1A2A10]",
  "myth-symbol":       "from-[#1A0A1F] via-[#2A1640] to-[#16455F]",
  "community":         "from-[#16455F] via-[#0F1B1F] to-[#16455F]",
  "science":           "from-[#0A0F1A] via-[#0F2040] to-[#16455F]",
  "geopolitics":       "from-[#1A1008] via-[#2A2010] to-[#16455F]",
};

// Ornamental motif text rendered at low opacity behind the hero headline
const VARIANT_MOTIFS: Record<HeroVariant, string> = {
  "knowledge-journey": "ज्ञान",
  "archive-scribe":    "लेखन",
  "culture-music":     "संगीत",
  "wanderer":          "यात्रा",
  "myth-symbol":       "मिथक",
  "community":         "समुदाय",
  "science":           "विज्ञान",
  "geopolitics":       "भूगोल",
};

export function HeroPanel({
  variant = "knowledge-journey",
  eyebrow,
  headline,
  subline,
  actions = [],
  dark = true,
  className,
  minHeight = "min-h-[60vh]",
  illustrationSrc,
}: HeroPanelProps) {
  const gradient = VARIANT_GRADIENTS[variant];
  const motif = VARIANT_MOTIFS[variant];

  return (
    <section
      className={cn(
        "relative overflow-hidden flex items-end",
        minHeight,
        dark ? "text-[var(--color-parchment)]" : "text-[var(--color-ink)]",
        className
      )}
    >
      {/* Background gradient */}
      <div
        className={cn("absolute inset-0 bg-gradient-to-br", gradient)}
        aria-hidden="true"
      />

      {/* Illustration overlay */}
      {illustrationSrc && (
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-40"
          style={{ backgroundImage: `url(${illustrationSrc})` }}
          aria-hidden="true"
        />
      )}

      {/* Parchment texture overlay */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='4' height='4'%3E%3Cpath d='M0 0h2v2H0zM2 2h2v2H2z' fill='%23F1EBD6'/%3E%3C/svg%3E")`,
        }}
        aria-hidden="true"
      />

      {/* Devanagari motif watermark */}
      <div
        className="absolute right-8 top-1/2 -translate-y-1/2 text-white/[0.04] font-[var(--font-display)] pointer-events-none select-none leading-none"
        style={{ fontSize: "clamp(8rem, 20vw, 18rem)" }}
        aria-hidden="true"
      >
        {motif}
      </div>

      {/* Gold ornament top-left */}
      <div
        className="absolute top-6 left-8 text-[var(--color-gold)] opacity-30 text-xs font-[var(--font-classical)] tracking-[0.3em] uppercase"
        aria-hidden="true"
      >
        ✦ &nbsp; Ānvīkṣikī &nbsp; ✦
      </div>

      {/* Content */}
      <motion.div
        className="relative z-10 container pb-16 pt-24 md:pb-20 md:pt-28"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      >
        <div className="max-w-2xl">
          {eyebrow && (
            <motion.p
              className="eyebrow mb-4 text-[var(--color-gold)] opacity-90"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 }}
            >
              {eyebrow}
            </motion.p>
          )}

          <h1
            className="font-[var(--font-display)] font-bold leading-[1.1] mb-4"
            style={{ fontSize: "clamp(2.25rem, 6vw, 4rem)" }}
          >
            {headline}
          </h1>

          {subline && (
            <p className="text-base md:text-lg opacity-80 mb-8 max-w-xl leading-relaxed">
              {subline}
            </p>
          )}

          {actions.length > 0 && (
            <div className="flex flex-wrap gap-3">
              {actions.map((action, i) => (
                <Button
                  key={i}
                  variant={action.variant ?? (i === 0 ? "primary" : "ghost")}
                  size="lg"
                  as={action.href ? "a" : "button"}
                  href={action.href}
                  onClick={action.onClick}
                  className={
                    i > 0
                      ? "text-[var(--color-parchment)] border-[var(--color-parchment)]/40 hover:bg-[var(--color-parchment)]/10"
                      : undefined
                  }
                >
                  {action.label}
                </Button>
              ))}
            </div>
          )}
        </div>
      </motion.div>

      {/* Bottom fade to page background */}
      <div
        className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-[var(--color-parchment)] to-transparent"
        aria-hidden="true"
      />
    </section>
  );
}
