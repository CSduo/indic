import React from "react";
import { cn } from "@/lib/utils";

// Ink-style SVG animal glyphs — simplified silhouettes matching the reference art direction.
// Each glyph is a 40×40 SVG path drawn in the platform ink colour.

type GlyphKey =
  | "elephant" | "ram"    | "tiger"   | "owl"
  | "serpent"  | "camel"  | "fish"    | "scorpion"
  | "monkey"   | "deer"   | "tortoise"| "horse"
  | "cat"      | "bull"   | "falcon"  | "lotus";

interface GlyphDef {
  viewBox: string;
  paths: string[];
}

// Simplified, stylised SVG paths inspired by traditional Indian motif line art.
const GLYPHS: Record<GlyphKey, GlyphDef> = {
  elephant: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 6c-5.5 0-10 3-10 8 0 2 .8 4 2 5.5V28a2 2 0 0 0 4 0v-3h8v3a2 2 0 0 0 4 0V19.5c1.2-1.5 2-3.5 2-5.5 0-5-4.5-8-10-8zm-4 8a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm8 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z",
      "M14 21h12v2H14z",
    ],
  },
  ram: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 8c-2 0-4 1-5 3-1.5 0-3 .5-4 2-1 1.5-.5 4 1 5 .5.5 1 .5 1.5.5v8a2 2 0 0 0 4 0v-4h5v4a2 2 0 0 0 4 0v-8c.5 0 1 0 1.5-.5 1.5-1 2-3.5 1-5-1-1.5-2.5-2-4-2-1-2-3-3-5-3z",
      "M15 11 Q12 8 11 11M25 11 Q28 8 29 11",
    ],
  },
  tiger: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 7c-6 0-10 4-10 9 0 3 1.5 5.5 4 7v5.5a2 2 0 0 0 4 0V26h4v2.5a2 2 0 0 0 4 0V23c2.5-1.5 4-4 4-7 0-5-4-9-10-9z",
      "M15.5 14a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zM24.5 14a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z",
      "M17 18 Q20 21 23 18",
    ],
  },
  owl: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 6c-5 0-9 4-9 9 0 3.5 2 6.5 5 8v4.5a2 2 0 0 0 4 0v-1h1v1a2 2 0 0 0 4 0V23c3-1.5 5-4.5 5-8 0-5-4-9-10-9z",
      "M16 13a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5zM24 13a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5z",
      "M17 16 Q20 18.5 23 16",
      "M19 7 L18 4M21 7 L22 4",
    ],
  },
  serpent: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 6c-2 0-3.5 1.5-3.5 3.5 0 2 1.5 3.5 3.5 3.5s3.5-1.5 3.5-3.5S22 6 20 6z",
      "M20 13 Q25 18 20 23 Q15 28 20 33",
      "M20 13 Q15 18 20 23 Q25 28 20 33",
    ],
  },
  camel: {
    viewBox: "0 0 40 40",
    paths: [
      "M13 15c0-4 2-7 5-7s3 2 4 2 3-2 4 0c1 2 1 4 1 6H13zm-1 1h16v2H12zm1 3H26l-1 10H14zm-2 0v10a2 2 0 0 0 4 0v-10zm14 0v10a2 2 0 0 0 4 0v-10z",
    ],
  },
  fish: {
    viewBox: "0 0 40 40",
    paths: [
      "M8 20 Q14 10 24 20 Q14 30 8 20z",
      "M24 20 Q28 15 34 20 Q28 25 24 20z",
      "M22 18 a2 2 0 1 1 0 4 2 2 0 0 1 0-4z",
    ],
  },
  scorpion: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 10 Q25 12 25 18 Q25 22 20 24 Q15 22 15 18 Q15 12 20 10z",
      "M25 18 Q30 18 32 14 Q34 10 32 8",
      "M20 24 Q20 30 16 34",
      "M14 16 L8 13M14 18 L8 18M14 20 L8 23",
      "M26 16 L32 13M26 18 L32 18M26 20 L32 23",
    ],
  },
  monkey: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 7c-4.5 0-8 3.5-8 8 0 3 1.5 5.5 4 7v5.5a2 2 0 0 0 4 0v-2h0v2a2 2 0 0 0 4 0V22c2.5-1.5 4-4 4-7 0-4.5-3.5-8-8-8z",
      "M16 13a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zM24 13a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z",
      "M17 17 Q20 20 23 17",
      "M20 7 Q20 3 24 3",
    ],
  },
  deer: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 12c-4 0-7 3-7 7 0 2.5 1.5 5 4 6.5v4a2 2 0 0 0 4 0v-4c2.5-1.5 4-4 4-6.5 0-4-3-7-5-7z",
      "M15 8 Q13 4 11 4 Q13 8 15 12",
      "M13 9 Q10 6 10 9",
      "M25 8 Q27 4 29 4 Q27 8 25 12",
      "M27 9 Q30 6 30 9",
    ],
  },
  tortoise: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 8c-6.5 0-12 5-12 10s5.5 10 12 10 12-5 12-10-5.5-10-12-10z",
      "M20 12 Q22 10 24 12 Q22 14 20 12z",
      "M16 14 Q18 12 20 14 Q18 16 16 14z",
      "M20 17 Q22 15 24 17 Q22 19 20 17z",
      "M16 20 Q18 18 20 20 Q18 22 16 20z",
      "M20 22c-2 0-3 1-3 2h6c0-1-1-2-3-2z",
      "M8 18 L5 22M32 18 L35 22M12 27 L10 31M28 27 L30 31",
    ],
  },
  horse: {
    viewBox: "0 0 40 40",
    paths: [
      "M22 7c-3 0-5 2-5 5 0 2 .8 3.5 2 4.5v1l-5 5v5.5a2 2 0 0 0 4 0v-4l3-3v7a2 2 0 0 0 4 0V22l2-2c1-1 2-2.5 2-4 0-5-3-9-7-9z",
      "M22 10a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z",
      "M19 6 Q21 3 24 4",
    ],
  },
  cat: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 9c-5 0-8 3.5-8 8 0 3 1.5 5.5 4 7v4a2 2 0 0 0 4 0v-1h0v1a2 2 0 0 0 4 0v-4c2.5-1.5 4-4 4-7 0-4.5-3-8-8-8z",
      "M16 13a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zM24 13a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z",
      "M17 17 Q20 20 23 17",
      "M15 8 L13 5M17 8 L16 5M25 8 L27 5M23 8 L24 5",
    ],
  },
  bull: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 8c-5.5 0-9 3.5-9 8 0 3 1.5 5.5 4 7v5a2 2 0 0 0 4 0v-3h2v3a2 2 0 0 0 4 0v-5c2.5-1.5 4-4 4-7 0-4.5-3.5-8-9-8z",
      "M15 14a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zM25 14a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z",
      "M11 8 Q8 4 10 8M29 8 Q32 4 30 8",
    ],
  },
  falcon: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 6c-2 0-3.5 1-3.5 3 0 1.5 1 2.5 2.5 3v2l-8 5h4v3l4-2v3h2v-3l4 2v-3h4l-8-5v-2c1.5-.5 2.5-1.5 2.5-3 0-2-1.5-3-3.5-3z",
      "M20 7.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z",
      "M16 25v7a2 2 0 0 0 4 0v-7M24 25v7a2 2 0 0 0-4 0v-7",
    ],
  },
  lotus: {
    viewBox: "0 0 40 40",
    paths: [
      "M20 28 Q14 20 14 14 Q17 18 20 20 Q23 18 26 14 Q26 20 20 28z",
      "M20 28 Q10 22 8 14 Q12 20 20 24z",
      "M20 28 Q30 22 32 14 Q28 20 20 24z",
      "M20 28 L20 34",
      "M16 33 Q20 31 24 33",
    ],
  },
};

interface AnimalGlyphProps {
  glyph: GlyphKey | string;
  size?: number;
  color?: string;
  className?: string;
  title?: string;
}

export function AnimalGlyph({
  glyph,
  size = 32,
  color = "currentColor",
  className,
  title,
}: AnimalGlyphProps) {
  const def = GLYPHS[glyph as GlyphKey];

  // Fallback: render a simple lotus for unknown glyphs
  const activeDef = def || GLYPHS.lotus;

  return (
    <svg
      width={size}
      height={size}
      viewBox={activeDef.viewBox}
      fill="none"
      stroke={color}
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn("shrink-0", className)}
      role={title ? "img" : "presentation"}
      aria-label={title}
      aria-hidden={!title}
    >
      {title && <title>{title}</title>}
      {activeDef.paths.map((d, i) => (
        <path key={i} d={d} />
      ))}
    </svg>
  );
}

export type { GlyphKey };
