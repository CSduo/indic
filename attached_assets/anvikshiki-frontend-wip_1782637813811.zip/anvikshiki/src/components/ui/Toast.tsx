import React from "react";
import { CheckCircle, XCircle, Info, AlertTriangle, X } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Toast as ToastType, ToastVariant } from "@/hooks/useToast";

const icons: Record<ToastVariant, React.ReactNode> = {
  success: <CheckCircle size={16} />,
  error:   <XCircle size={16} />,
  warning: <AlertTriangle size={16} />,
  info:    <Info size={16} />,
};

const variantStyles: Record<ToastVariant, string> = {
  success: "bg-[var(--color-teal)] text-[var(--color-parchment)] border-[var(--color-teal)]",
  error:   "bg-red-700 text-white border-red-700",
  warning: "bg-[var(--color-rust)] text-white border-[var(--color-rust)]",
  info:    "bg-[var(--color-ink)] text-[var(--color-parchment)] border-[var(--color-ink)]",
};

interface ToastItemProps {
  toast: ToastType;
  onRemove: (id: string) => void;
}

function ToastItem({ toast, onRemove }: ToastItemProps) {
  return (
    <div
      className={cn(
        "flex items-center gap-3 px-4 py-3 rounded-[var(--radius-lg)] border",
        "shadow-[var(--shadow-modal)] min-w-[260px] max-w-[380px]",
        "pointer-events-auto animate-in slide-in-from-bottom-2 fade-in duration-200",
        variantStyles[toast.variant]
      )}
      role="alert"
    >
      <span aria-hidden="true" className="shrink-0">{icons[toast.variant]}</span>
      <span className="text-sm font-medium flex-1">{toast.message}</span>
      <button
        onClick={() => onRemove(toast.id)}
        className="shrink-0 opacity-70 hover:opacity-100 transition-opacity"
        aria-label="Dismiss"
      >
        <X size={14} />
      </button>
    </div>
  );
}

interface ToastContainerProps {
  toasts: ToastType[];
  onRemove: (id: string) => void;
}

export function ToastContainer({ toasts, onRemove }: ToastContainerProps) {
  if (!toasts.length) return null;
  return (
    <div className="toast-container" aria-live="polite" aria-label="Notifications">
      {toasts.map((t) => (
        <ToastItem key={t.id} toast={t} onRemove={onRemove} />
      ))}
    </div>
  );
}
