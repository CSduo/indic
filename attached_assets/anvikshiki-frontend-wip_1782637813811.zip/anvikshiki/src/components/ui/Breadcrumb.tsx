import React from "react";
import { ChevronRight, ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

interface Crumb {
  label: string;
  href?: string;
}

interface BreadcrumbProps {
  crumbs: Crumb[];
  backHref?: string;
  backLabel?: string;
  className?: string;
}

export function Breadcrumb({
  crumbs,
  backHref,
  backLabel,
  className,
}: BreadcrumbProps) {
  return (
    <nav
      aria-label="Breadcrumb"
      className={cn("flex items-center gap-2 flex-wrap", className)}
    >
      {backHref && (
        <a
          href={backHref}
          className="inline-flex items-center gap-1.5 text-sm text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors mr-2"
          aria-label={backLabel || "Go back"}
        >
          <ArrowLeft size={14} />
          <span>{backLabel || "Back"}</span>
        </a>
      )}

      <ol className="flex items-center gap-1 flex-wrap" role="list">
        {crumbs.map((crumb, i) => {
          const isLast = i === crumbs.length - 1;
          return (
            <li key={i} className="flex items-center gap-1">
              {i > 0 && (
                <ChevronRight
                  size={12}
                  className="text-[var(--color-border)]"
                  aria-hidden="true"
                />
              )}
              {crumb.href && !isLast ? (
                <a
                  href={crumb.href}
                  className="text-sm text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors"
                >
                  {crumb.label}
                </a>
              ) : (
                <span
                  className={cn(
                    "text-sm",
                    isLast
                      ? "text-[var(--color-ink)] font-medium"
                      : "text-[var(--color-muted)]"
                  )}
                  aria-current={isLast ? "page" : undefined}
                >
                  {crumb.label}
                </span>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
