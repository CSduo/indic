import React from "react";
import { cn } from "@/lib/utils";

interface SkeletonProps {
  className?: string;
  width?: string | number;
  height?: string | number;
}

export function Skeleton({ className, width, height }: SkeletonProps) {
  return (
    <div
      aria-hidden="true"
      className={cn(
        "animate-pulse rounded-[var(--radius-md)] bg-[var(--color-parchment-dark)]",
        className
      )}
      style={{ width, height }}
    />
  );
}

export function CardSkeleton() {
  return (
    <div className="card p-5 flex flex-col gap-3">
      <div className="flex gap-2 items-center">
        <Skeleton className="w-6 h-6 rounded-full" />
        <Skeleton className="w-24 h-3" />
      </div>
      <Skeleton className="w-full h-5" />
      <Skeleton className="w-4/5 h-5" />
      <Skeleton className="w-full h-3" />
      <Skeleton className="w-3/4 h-3" />
      <div className="flex gap-4 items-center mt-1">
        <Skeleton className="w-20 h-3" />
        <Skeleton className="w-16 h-3" />
      </div>
    </div>
  );
}

export function HeroSkeleton() {
  return (
    <div className="animate-pulse bg-[var(--color-teal)]/20 w-full h-[60vh] min-h-[420px] rounded-[var(--radius-xl)]" />
  );
}

export function GridSkeleton({ count = 3 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
      {Array.from({ length: count }).map((_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  );
}
