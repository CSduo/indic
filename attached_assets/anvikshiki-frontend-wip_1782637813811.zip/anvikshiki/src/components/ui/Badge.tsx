import React from "react";
import { cn } from "@/lib/utils";

type BadgeVariant = "gold" | "teal" | "rust" | "gray" | "green" | "red" | "amber" | "blue";

interface BadgeProps {
  variant?: BadgeVariant;
  children: React.ReactNode;
  className?: string;
  size?: "xs" | "sm";
  dot?: boolean;
}

const variantStyles: Record<BadgeVariant, string> = {
  gold:  "bg-[var(--color-gold)]/15 text-[#7A6520] border-[var(--color-gold)]/30",
  teal:  "bg-[var(--color-teal)]/15 text-[var(--color-teal)] border-[var(--color-teal)]/30",
  rust:  "bg-[var(--color-rust)]/15 text-[var(--color-rust)] border-[var(--color-rust)]/30",
  gray:  "bg-[var(--color-parchment-dark)] text-[var(--color-muted)] border-[var(--color-border)]",
  green: "bg-green-50 text-green-700 border-green-200",
  red:   "bg-red-50 text-red-700 border-red-200",
  amber: "bg-amber-50 text-amber-700 border-amber-200",
  blue:  "bg-blue-50 text-blue-700 border-blue-200",
};

const dotStyles: Record<BadgeVariant, string> = {
  gold:  "bg-[var(--color-gold)]",
  teal:  "bg-[var(--color-teal)]",
  rust:  "bg-[var(--color-rust)]",
  gray:  "bg-[var(--color-muted)]",
  green: "bg-green-500",
  red:   "bg-red-500",
  amber: "bg-amber-500",
  blue:  "bg-blue-500",
};

export function Badge({
  variant = "gray",
  children,
  className,
  size = "sm",
  dot = false,
}: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 border rounded-full font-[var(--font-ui)] font-medium leading-none",
        size === "xs" ? "text-[10px] px-2 py-0.5" : "text-[11px] px-2.5 py-1",
        variantStyles[variant],
        className
      )}
    >
      {dot && (
        <span
          className={cn("w-1.5 h-1.5 rounded-full shrink-0", dotStyles[variant])}
          aria-hidden="true"
        />
      )}
      {children}
    </span>
  );
}

// Submission status badge
import { SUBMISSION_STATUSES, type SubmissionStatus } from "@/lib/constants";

const statusVariants: Record<string, BadgeVariant> = {
  draft: "gray",
  submitted: "blue",
  under_review: "amber",
  revision_requested: "amber",
  resubmitted: "blue",
  accepted: "green",
  rejected: "red",
  published: "teal",
  archived: "gray",
};

export function StatusBadge({ status }: { status: string }) {
  const info = SUBMISSION_STATUSES[status as SubmissionStatus];
  const variant = statusVariants[status] ?? "gray";
  return (
    <Badge variant={variant} dot>
      {info?.label ?? status}
    </Badge>
  );
}

// Domain badge
export function DomainChip({ label, slug }: { label: string; slug?: string }) {
  return (
    <span className="eyebrow">
      {label}
    </span>
  );
}
