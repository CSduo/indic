import React from "react";
import { cn } from "@/lib/utils";
import { Button } from "./Button";

interface EmptyStateProps {
  glyph?: string;
  title: string;
  description?: string;
  action?: {
    label: string;
    onClick?: () => void;
    href?: string;
    variant?: "primary" | "secondary" | "ghost";
  };
  secondaryAction?: {
    label: string;
    onClick?: () => void;
    href?: string;
  };
  className?: string;
  compact?: boolean;
}

export function EmptyState({
  glyph = "📜",
  title,
  description,
  action,
  secondaryAction,
  className,
  compact = false,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center text-center",
        compact ? "py-8 gap-3" : "py-16 gap-4",
        className
      )}
    >
      <div
        className={cn(
          "flex items-center justify-center rounded-full bg-[var(--color-parchment-dark)] text-[var(--color-muted)]",
          compact ? "w-12 h-12 text-2xl" : "w-16 h-16 text-3xl"
        )}
        aria-hidden="true"
      >
        {glyph}
      </div>

      <div className={cn("flex flex-col", compact ? "gap-1" : "gap-2")}>
        <h3
          className={cn(
            "font-[var(--font-display)] font-semibold text-[var(--color-ink)]",
            compact ? "text-base" : "text-lg"
          )}
        >
          {title}
        </h3>
        {description && (
          <p
            className={cn(
              "text-[var(--color-muted)] max-w-sm",
              compact ? "text-sm" : "text-sm"
            )}
          >
            {description}
          </p>
        )}
      </div>

      {(action || secondaryAction) && (
        <div className="flex flex-wrap items-center justify-center gap-3 mt-1">
          {action && (
            <Button
              variant={action.variant ?? "primary"}
              size={compact ? "sm" : "md"}
              onClick={action.onClick}
              as={action.href ? "a" : "button"}
              href={action.href}
            >
              {action.label}
            </Button>
          )}
          {secondaryAction && (
            <Button
              variant="ghost"
              size={compact ? "sm" : "md"}
              onClick={secondaryAction.onClick}
              as={secondaryAction.href ? "a" : "button"}
              href={secondaryAction.href}
            >
              {secondaryAction.label}
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
