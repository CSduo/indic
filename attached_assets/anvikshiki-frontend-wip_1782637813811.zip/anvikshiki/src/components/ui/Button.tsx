import React from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "outline";
type Size    = "xs" | "sm" | "md" | "lg";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
  fullWidth?: boolean;
  as?: "button" | "a";
  href?: string;
}

const variantClasses: Record<Variant, string> = {
  primary:
    "bg-[var(--color-gold)] hover:bg-[var(--color-gold-light)] text-[var(--color-ink)] font-medium border border-[var(--color-gold)]",
  secondary:
    "bg-[var(--color-teal)] hover:bg-[var(--color-teal)]/90 text-[var(--color-parchment)] font-medium border border-[var(--color-teal)]",
  ghost:
    "bg-transparent hover:bg-[var(--color-parchment-dark)] text-[var(--color-ink)] border border-transparent hover:border-[var(--color-border)]",
  danger:
    "bg-red-600 hover:bg-red-700 text-white font-medium border border-red-600",
  outline:
    "bg-transparent border border-[var(--color-ink)] text-[var(--color-ink)] hover:bg-[var(--color-ink)] hover:text-[var(--color-parchment)]",
};

const sizeClasses: Record<Size, string> = {
  xs:  "text-xs px-2.5 py-1 rounded-[var(--radius-sm)] gap-1",
  sm:  "text-sm px-3.5 py-1.5 rounded-[var(--radius-md)] gap-1.5",
  md:  "text-sm px-5 py-2.5 rounded-[var(--radius-md)] gap-2",
  lg:  "text-base px-7 py-3 rounded-[var(--radius-lg)] gap-2",
};

export function Button({
  variant = "primary",
  size = "md",
  loading = false,
  icon,
  iconRight,
  fullWidth = false,
  children,
  className,
  disabled,
  as: Tag = "button",
  href,
  ...props
}: ButtonProps) {
  const cls = cn(
    "inline-flex items-center justify-center whitespace-nowrap transition-all duration-200",
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--color-gold)] focus-visible:ring-offset-1",
    "disabled:opacity-50 disabled:cursor-not-allowed disabled:pointer-events-none",
    "font-[var(--font-ui)]",
    variantClasses[variant],
    sizeClasses[size],
    fullWidth && "w-full",
    className
  );

  const content = (
    <>
      {loading ? (
        <svg
          className="animate-spin"
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          aria-hidden="true"
        >
          <circle cx="12" cy="12" r="10" strokeOpacity="0.25" />
          <path d="M12 2a10 10 0 0 1 10 10" />
        </svg>
      ) : icon ? (
        <span aria-hidden="true">{icon}</span>
      ) : null}
      {children}
      {iconRight && !loading && (
        <span aria-hidden="true">{iconRight}</span>
      )}
    </>
  );

  if (Tag === "a" && href) {
    return (
      <a href={href} className={cls}>
        {content}
      </a>
    );
  }

  return (
    <button className={cls} disabled={disabled || loading} {...props}>
      {content}
    </button>
  );
}
