import React from "react";
import { Modal } from "@/components/ui/Modal";
import { Button } from "@/components/ui/Button";
import { AnimalGlyph } from "@/components/glyphs/AnimalGlyph";
import { SITE_NAME } from "@/lib/constants";

interface AuthGateProps {
  open: boolean;
  onClose: () => void;
  reason?: string;
}

export function AuthGate({ open, onClose, reason }: AuthGateProps) {
  return (
    <Modal open={open} onClose={onClose} size="sm">
      <div className="flex flex-col items-center text-center gap-4">
        {/* Emblem / glyph */}
        <div className="w-14 h-14 flex items-center justify-center rounded-full bg-[var(--color-teal)]/10 text-[var(--color-teal)]">
          <AnimalGlyph glyph="lotus" size={28} />
        </div>

        <div>
          <h2 className="font-[var(--font-display)] text-xl font-bold text-[var(--color-ink)]">
            Join {SITE_NAME}
          </h2>
          <p className="text-sm text-[var(--color-muted)] mt-2 leading-relaxed max-w-xs">
            {reason ??
              "Create an account to save essays, submit work, write drafts, and join the community."}
          </p>
        </div>

        <div className="flex flex-col gap-2.5 w-full">
          <Button
            as="a"
            href="/signup"
            variant="primary"
            fullWidth
            onClick={onClose}
          >
            Create account
          </Button>
          <Button
            as="a"
            href="/login"
            variant="ghost"
            fullWidth
            onClick={onClose}
          >
            Sign in
          </Button>
        </div>

        <button
          onClick={onClose}
          className="text-xs text-[var(--color-muted)] hover:text-[var(--color-ink)] transition-colors"
        >
          Continue browsing
        </button>
      </div>
    </Modal>
  );
}
