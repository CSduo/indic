import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ─── Reading time ─────────────────────────────────────────────────────────────
export function estimateReadingTime(wordCount: number): string {
  const wpm = 220;
  const minutes = Math.max(1, Math.round(wordCount / wpm));
  return `${minutes} min read`;
}

export function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

// ─── Date formatting ──────────────────────────────────────────────────────────
const DATE_FMT = new Intl.DateTimeFormat("en-IN", {
  year: "numeric",
  month: "short",
  day: "numeric",
});

const DATE_LONG_FMT = new Intl.DateTimeFormat("en-IN", {
  year: "numeric",
  month: "long",
  day: "numeric",
});

export function formatDate(date: string | Date): string {
  return DATE_FMT.format(new Date(date));
}

export function formatDateLong(date: string | Date): string {
  return DATE_LONG_FMT.format(new Date(date));
}

export function timeAgo(date: string | Date): string {
  const now = Date.now();
  const then = new Date(date).getTime();
  const diffMs = now - then;
  const diffS = Math.floor(diffMs / 1000);
  const diffM = Math.floor(diffS / 60);
  const diffH = Math.floor(diffM / 60);
  const diffD = Math.floor(diffH / 24);
  if (diffS < 60) return "just now";
  if (diffM < 60) return `${diffM}m ago`;
  if (diffH < 24) return `${diffH}h ago`;
  if (diffD < 7)  return `${diffD}d ago`;
  return formatDate(date);
}

// ─── Slug / text helpers ──────────────────────────────────────────────────────
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function truncate(text: string, maxLen = 160): string {
  if (text.length <= maxLen) return text;
  return text.slice(0, maxLen).replace(/\s+\S*$/, "") + "…";
}

export function capitalize(str: string): string {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// ─── File size ────────────────────────────────────────────────────────────────
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// ─── Domain color accent ──────────────────────────────────────────────────────
export function getDomainAccent(slug: string): string {
  const accents: Record<string, string> = {
    philosophy:        "#16455F",
    history:           "#B99A42",
    "arts-literature": "#C26A4F",
    "science-knowledge": "#4A7B8C",
    spiritual:         "#7B5EA7",
    "living-traditions": "#5A8A4A",
    psychology:        "#8A6040",
    sociology:         "#405A8A",
    geopolitics:       "#8A4040",
    papers:            "#606060",
    archive:           "#8A7040",
    multimedia:        "#40608A",
  };
  return accents[slug] || "#B99A42";
}

// ─── Local draft backup ───────────────────────────────────────────────────────
const DRAFT_BACKUP_KEY = "anvikshiki_draft_backup";

interface DraftBackup {
  draftId: string;
  title: string;
  content: string;
  savedAt: string;
}

export function saveDraftBackup(backup: DraftBackup): void {
  try {
    sessionStorage.setItem(DRAFT_BACKUP_KEY, JSON.stringify(backup));
  } catch {}
}

export function getDraftBackup(): DraftBackup | null {
  try {
    const raw = sessionStorage.getItem(DRAFT_BACKUP_KEY);
    return raw ? (JSON.parse(raw) as DraftBackup) : null;
  } catch {
    return null;
  }
}

export function clearDraftBackup(): void {
  try {
    sessionStorage.removeItem(DRAFT_BACKUP_KEY);
  } catch {}
}
