import { API_URL } from "@/env";

// ─── Auth token storage (sessionStorage — safer than localStorage for tokens) ─
const TOKEN_KEY = "anvikshiki_token";
const ADMIN_TOKEN_KEY = "anvikshiki_admin_token";

export function getToken(): string | null {
  try { return sessionStorage.getItem(TOKEN_KEY); } catch { return null; }
}
export function setToken(token: string): void {
  try { sessionStorage.setItem(TOKEN_KEY, token); } catch {}
}
export function clearToken(): void {
  try {
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(ADMIN_TOKEN_KEY);
  } catch {}
}
export function getAdminToken(): string | null {
  try { return sessionStorage.getItem(ADMIN_TOKEN_KEY); } catch { return null; }
}
export function setAdminToken(token: string): void {
  try { sessionStorage.setItem(ADMIN_TOKEN_KEY, token); } catch {}
}

// ─── API error ────────────────────────────────────────────────────────────────
export class ApiError extends Error {
  constructor(public status: number, message: string, public body?: unknown) {
    super(message);
    this.name = "ApiError";
  }
}

// ─── Base fetch wrapper ───────────────────────────────────────────────────────
async function apiFetch<T>(
  path: string,
  options: RequestInit & { skipAuth?: boolean; adminAuth?: boolean } = {}
): Promise<T> {
  const { skipAuth, adminAuth, ...fetchOpts } = options;
  const token = adminAuth ? getAdminToken() : getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(fetchOpts.headers as Record<string, string> | undefined),
  };

  if (!skipAuth && token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  // In dev, Vite proxy handles /api → localhost:8080
  // In prod, VITE_API_URL is the Replit server URL
  const url = `${API_URL}/api${path}`;

  const res = await fetch(url, { ...fetchOpts, headers });

  if (!res.ok) {
    let message = `HTTP ${res.status}`;
    let body: unknown;
    try {
      body = await res.json();
      if (body && typeof body === "object" && "message" in body) {
        message = (body as { message: string }).message;
      }
    } catch {}
    throw new ApiError(res.status, message, body);
  }

  if (res.status === 204 || res.headers.get("content-length") === "0") {
    return undefined as T;
  }

  return res.json() as Promise<T>;
}

// ─── Convenience wrappers ─────────────────────────────────────────────────────
export const api = {
  get: <T>(path: string, opts?: RequestInit) =>
    apiFetch<T>(path, { method: "GET", ...opts }),

  post: <T>(path: string, body?: unknown, opts?: RequestInit) =>
    apiFetch<T>(path, { method: "POST", body: JSON.stringify(body), ...opts }),

  put: <T>(path: string, body?: unknown, opts?: RequestInit) =>
    apiFetch<T>(path, { method: "PUT", body: JSON.stringify(body), ...opts }),

  patch: <T>(path: string, body?: unknown, opts?: RequestInit) =>
    apiFetch<T>(path, { method: "PATCH", body: JSON.stringify(body), ...opts }),

  delete: <T>(path: string, opts?: RequestInit) =>
    apiFetch<T>(path, { method: "DELETE", ...opts }),

  upload: <T>(path: string, formData: FormData, opts?: RequestInit) => {
    // Remove Content-Type so browser sets multipart boundary automatically
    const token = getToken();
    const headers: Record<string, string> = {};
    if (token) headers["Authorization"] = `Bearer ${token}`;
    const url = `${API_URL}/api${path}`;
    return fetch(url, { method: "POST", body: formData, headers, ...opts })
      .then(async (res) => {
        if (!res.ok) {
          let message = `HTTP ${res.status}`;
          try {
            const body = await res.json();
            if (body?.message) message = body.message;
          } catch {}
          throw new ApiError(res.status, message);
        }
        return res.json() as Promise<T>;
      });
  },
};

// ─── Types ────────────────────────────────────────────────────────────────────
export interface User {
  id: string;
  email: string;
  displayName: string;
  username?: string;
  role: "user" | "editor" | "admin";
  avatarUrl?: string;
  avatarGlyph?: string;
  bio?: string;
  interests?: string[];
  communityJoined?: boolean;
}

export interface Article {
  id: string;
  slug: string;
  title: string;
  subtitle?: string;
  excerpt?: string;
  contentHtml?: string;
  domain: string;
  tags: string[];
  authorName: string;
  authorBio?: string;
  authorAvatarUrl?: string;
  coverImage?: string;
  status: "published" | "draft" | "archived";
  publishedAt: string;
  updatedAt?: string;
  readingTime?: number;
  wordCount?: number;
  featured?: boolean;
}

export interface Paper {
  id: string;
  slug: string;
  title: string;
  abstract: string;
  authors: string[];
  domain: string;
  tags: string[];
  fileUrl?: string;
  status: "published" | "draft";
  peerReviewed?: boolean;
  workingPaper?: boolean;
  publishedAt: string;
  downloads?: number;
  citation?: string;
}

export interface Domain {
  slug: string;
  name: string;
  description: string;
  glyphKey: string;
  contentCount?: number;
  paperCount?: number;
  isActive?: boolean;
}

export interface Draft {
  id: string;
  title?: string;
  subtitle?: string;
  contentJson?: string;
  contentHtml?: string;
  plainText?: string;
  status: "draft" | "imported" | "submitted" | "revision_requested" | "archived";
  mode?: "essay" | "paper" | "note";
  sourceType?: "scratch" | "import";
  wordCount?: number;
  readingTime?: number;
  lastSavedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Submission {
  id: string;
  draftId?: string;
  type: string;
  title: string;
  status: string;
  submittedAt: string;
  reviewedAt?: string;
  authorNote?: string;
  adminNote?: string;
  publishedArticleId?: string;
  publishedSlug?: string;
}

export interface SavedItem {
  id: string;
  contentType: "essay" | "paper" | "domain" | "collection";
  contentId: string;
  title?: string;
  createdAt: string;
}

export interface Collection {
  id: string;
  title: string;
  description?: string;
  itemCount: number;
  visibility: "private" | "public";
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  link?: string;
  readAt?: string;
  createdAt: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}

// ─── Auth endpoints ───────────────────────────────────────────────────────────
export const authApi = {
  me: () => api.get<User>("/auth/me"),

  login: async (email: string, password: string) => {
    const res = await api.post<{ token: string; user: User }>(
      "/auth/login", { email, password }, { skipAuth: true } as RequestInit & { skipAuth: boolean }
    );
    setToken(res.token);
    return res.user;
  },

  signup: async (data: {
    email: string;
    password: string;
    displayName: string;
    interests?: string[];
    avatarGlyph?: string;
  }) => {
    const res = await api.post<{ token: string; user: User }>(
      "/auth/register", data, { skipAuth: true } as RequestInit & { skipAuth: boolean }
    );
    setToken(res.token);
    return res.user;
  },

  logout: () => {
    clearToken();
    return Promise.resolve();
  },

  adminLogin: async (email: string, password: string) => {
    const res = await api.post<{ token: string; user: User }>(
      "/auth/admin/login", { email, password }, { skipAuth: true } as RequestInit & { skipAuth: boolean }
    );
    setAdminToken(res.token);
    return res.user;
  },
};

// ─── Content endpoints ────────────────────────────────────────────────────────
export const contentApi = {
  essays: (params?: Record<string, string>) => {
    const qs = params ? "?" + new URLSearchParams(params).toString() : "";
    return api.get<PaginatedResponse<Article>>(`/essays${qs}`);
  },

  essay: (slug: string) => api.get<Article>(`/essays/${slug}`),

  papers: (params?: Record<string, string>) => {
    const qs = params ? "?" + new URLSearchParams(params).toString() : "";
    return api.get<PaginatedResponse<Paper>>(`/papers${qs}`);
  },

  paper: (slug: string) => api.get<Paper>(`/papers/${slug}`),

  domains: () => api.get<Domain[]>("/domains"),
  domain:  (slug: string) => api.get<Domain & { articles: Article[]; papers: Paper[] }>(`/domains/${slug}`),

  search: (q: string, params?: Record<string, string>) => {
    const qs = new URLSearchParams({ q, ...params }).toString();
    return api.get<{ results: (Article | Paper)[]; total: number }>(`/search?${qs}`);
  },

  home: () => api.get<{
    featured?: Article;
    latestEssays: Article[];
    latestPapers: Paper[];
    domains: Domain[];
  }>("/home"),

  archive: (params?: Record<string, string>) => {
    const qs = params ? "?" + new URLSearchParams(params).toString() : "";
    return api.get<PaginatedResponse<Article | Paper>>(`/archive${qs}`);
  },
};

// ─── Draft endpoints ──────────────────────────────────────────────────────────
export const draftApi = {
  list: () => api.get<Draft[]>("/drafts"),
  get:  (id: string) => api.get<Draft>(`/drafts/${id}`),
  create: (data?: Partial<Draft>) => api.post<Draft>("/drafts", data),
  update: (id: string, data: Partial<Draft>) => api.patch<Draft>(`/drafts/${id}`, data),
  delete: (id: string) => api.delete<void>(`/drafts/${id}`),
  submit: (id: string, metadata: Record<string, unknown>) =>
    api.post<Submission>(`/drafts/${id}/submit`, metadata),
  importDocument: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return api.upload<{ draftId: string; wordCount: number; warnings: string[] }>(
      "/import-document", form
    );
  },
};

// ─── Submission endpoints ─────────────────────────────────────────────────────
export const submissionApi = {
  list: () => api.get<Submission[]>("/submissions"),
  get:  (id: string) => api.get<Submission>(`/submissions/${id}`),
  resubmit: (id: string) => api.post<Submission>(`/submissions/${id}/resubmit`),
};

// ─── Saved / collection endpoints ─────────────────────────────────────────────
export const savedApi = {
  list: () => api.get<SavedItem[]>("/saved"),
  save: (contentType: string, contentId: string, collectionId?: string) =>
    api.post<SavedItem>("/saved", { contentType, contentId, collectionId }),
  unsave: (itemId: string) => api.delete<void>(`/saved/${itemId}`),
  isSaved: (contentType: string, contentId: string) =>
    api.get<{ saved: boolean; itemId?: string }>(`/saved/check?contentType=${contentType}&contentId=${contentId}`),
};

export const collectionApi = {
  list: () => api.get<Collection[]>("/collections"),
  get:  (id: string) => api.get<Collection & { items: SavedItem[] }>(`/collections/${id}`),
  create: (data: { title: string; description?: string }) =>
    api.post<Collection>("/collections", data),
  update: (id: string, data: Partial<Collection>) =>
    api.patch<Collection>(`/collections/${id}`, data),
  delete: (id: string) => api.delete<void>(`/collections/${id}`),
};

// ─── Profile endpoints ────────────────────────────────────────────────────────
export const profileApi = {
  update: (data: Partial<User>) => api.patch<User>("/profile", data),
  uploadAvatar: (file: File) => {
    const form = new FormData();
    form.append("avatar", file);
    return api.upload<{ avatarUrl: string }>("/profile/avatar", form);
  },
};

// ─── Notification endpoints ───────────────────────────────────────────────────
export const notificationApi = {
  list: () => api.get<Notification[]>("/notifications"),
  markRead: (id: string) => api.patch<void>(`/notifications/${id}/read`),
  markAllRead: () => api.post<void>("/notifications/read-all"),
};

// ─── Newsletter ───────────────────────────────────────────────────────────────
export const newsletterApi = {
  subscribe: (email: string) =>
    api.post<{ message: string }>("/newsletter/subscribe", { email }),
};

// ─── Admin endpoints ──────────────────────────────────────────────────────────
export const adminApi = {
  dashboard: () => api.get<{
    pendingCount: number;
    publishedCount: number;
    draftCount: number;
    userCount: number;
  }>("/admin/dashboard"),

  submissions: (params?: Record<string, string>) => {
    const qs = params ? "?" + new URLSearchParams(params).toString() : "";
    return api.get<PaginatedResponse<Submission>>(`/admin/submissions${qs}`);
  },

  submission: (id: string) =>
    api.get<Submission & { draft?: Draft; files?: unknown[] }>(`/admin/submissions/${id}`),

  updateStatus: (id: string, status: string, note?: string) =>
    api.patch<Submission>(`/admin/submissions/${id}/status`, { status, note }),

  publish: (submissionId: string) =>
    api.post<Article>(`/admin/submissions/${submissionId}/publish`),
};
