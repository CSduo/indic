// ─── Domains ──────────────────────────────────────────────────────────────────
export interface Domain {
  slug: string;
  name: string;
  glyph: string; // animal glyph key
  description: string;
  accent?: string;
}

export const DOMAINS: Domain[] = [
  { slug: "philosophy",       name: "Philosophy",          glyph: "elephant", description: "Ideas, logic, ethics, and the examined life." },
  { slug: "history",          name: "History & Civilizations", glyph: "ram",  description: "Tracing the arc of human civilizations across time." },
  { slug: "arts-literature",  name: "Arts & Literature",   glyph: "tiger",    description: "Creativity, expression, and the written form." },
  { slug: "science-knowledge",name: "Science & Knowledge", glyph: "owl",      description: "The pursuit of understanding the natural world." },
  { slug: "spiritual",        name: "Spiritual Traditions",glyph: "serpent",  description: "Inquiry into meaning, practice, and transcendence." },
  { slug: "living-traditions",name: "Living Traditions",   glyph: "camel",    description: "Customs, crafts, music, and ways of life." },
  { slug: "psychology",       name: "Psychology",          glyph: "cat",      description: "Mind, behavior, and the inner landscape." },
  { slug: "sociology",        name: "Sociology",           glyph: "fish",     description: "Society, community, and collective life." },
  { slug: "geopolitics",      name: "Geopolitics",         glyph: "horse",    description: "Power, geography, and the movement of civilizations." },
  { slug: "papers",           name: "Research Papers",     glyph: "scorpion", description: "Peer-reviewed and working papers across disciplines." },
  { slug: "archive",          name: "Archive",             glyph: "tortoise", description: "Manuscripts, collections, timelines, and maps." },
  { slug: "multimedia",       name: "Multimedia",          glyph: "deer",     description: "Visual essays, audio, lectures, and recordings." },
];

// ─── Editorial content types ──────────────────────────────────────────────────
export const CONTENT_TYPES = [
  "essay",
  "academic-paper",
  "working-paper",
  "commentary",
  "review",
  "translation",
  "research-note",
  "archive-note",
  "visual-essay",
  "interview",
  "discussion",
  "note",
] as const;

export type ContentType = typeof CONTENT_TYPES[number];

// ─── Submission statuses ──────────────────────────────────────────────────────
export const SUBMISSION_STATUSES = {
  draft:             { label: "Draft",            color: "gray" },
  submitted:         { label: "Received",         color: "blue" },
  under_review:      { label: "Under Review",     color: "amber" },
  revision_requested:{ label: "Revision Needed",  color: "orange" },
  resubmitted:       { label: "Resubmitted",      color: "blue" },
  accepted:          { label: "Accepted",         color: "green" },
  rejected:          { label: "Not accepted",     color: "red" },
  published:         { label: "Published",        color: "teal" },
  archived:          { label: "Archived",         color: "gray" },
} as const;

export type SubmissionStatus = keyof typeof SUBMISSION_STATUSES;

// ─── Avatar glyphs available for user selection ───────────────────────────────
export const AVATAR_GLYPHS = [
  "elephant", "ram", "tiger", "owl", "serpent", "camel",
  "fish", "scorpion", "monkey", "deer", "tortoise", "horse",
  "cat", "bull", "falcon",
] as const;

export type AvatarGlyph = typeof AVATAR_GLYPHS[number];

// ─── Interest tags for signup ─────────────────────────────────────────────────
export const INTEREST_TAGS = [
  "Philosophy", "History", "Psychology", "Sociology", "Geopolitics",
  "Science", "Arts & Literature", "Spiritual Traditions", "Living Traditions",
  "Music", "Culture", "Archive", "Mythology", "Ecology", "Languages",
];

// ─── Nav links ─────────────────────────────────────────────────────────────────
export const NAV_LINKS = [
  { href: "/explore",   label: "Explore" },
  { href: "/archive",   label: "Archive" },
  { href: "/essays",    label: "Essays" },
  { href: "/papers",    label: "Papers" },
  { href: "/community", label: "Community" },
] as const;

// ─── Supported import formats ──────────────────────────────────────────────────
export const SUPPORTED_IMPORT_FORMATS = [
  { ext: ".docx", label: "DOCX", mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
  { ext: ".txt",  label: "TXT",  mime: "text/plain" },
  { ext: ".md",   label: "MD",   mime: "text/markdown" },
  { ext: ".pdf",  label: "PDF",  mime: "application/pdf" },
  { ext: ".odt",  label: "ODT",  mime: "application/vnd.oasis.opendocument.text" },
] as const;

export const MAX_UPLOAD_SIZE_MB = 10;
export const MAX_UPLOAD_SIZE = MAX_UPLOAD_SIZE_MB * 1024 * 1024;

// ─── Site identity ─────────────────────────────────────────────────────────────
export const SITE_NAME = "Ānvīkṣikī";
export const SITE_TAGLINE = "Journal & Research Platform";
export const SITE_DESCRIPTION = "A space for inquiry across time, traditions, and civilizations.";
export const SITE_DOMAIN = "anvikshiki.in";
