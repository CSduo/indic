// All environment variables accessed from one place.
// In dev, Vite proxies /api → API server, so VITE_API_URL is not needed locally.
// In production (Vercel), VITE_API_URL must point to the Replit API server.

export const API_URL =
  (import.meta.env.VITE_API_URL as string | undefined) || "";

// The base URL for file/asset downloads from the API server
export const ASSET_BASE =
  (import.meta.env.VITE_ASSET_BASE as string | undefined) ||
  API_URL ||
  "http://localhost:8080";

export const SITE_DOMAIN =
  (import.meta.env.VITE_SITE_DOMAIN as string | undefined) ||
  "anvikshiki.in";

export const IS_DEV = import.meta.env.DEV;
